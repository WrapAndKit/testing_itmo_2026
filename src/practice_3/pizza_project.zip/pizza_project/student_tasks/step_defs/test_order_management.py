"""
СТАРТОВЫЙ ФАЙЛ — Пара 5, упражнение по BDD.

Задача:
    Дописать step definitions для сценариев из
    student_tasks/features/order_management.feature

Эталон: tests/bdd/step_defs/test_order_creation.py

Как запустить:
    python -m pytest student_tasks/step_defs/test_order_management.py -v
"""

import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path

import pytest
from pytest_bdd import scenarios, given, when, then, parsers

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from pizza_service.domain import (
    CATALOG,
    Customer,
    Order,
    OrderService,
    OrderStatus,
    PizzaSize,
    PricingService,
)

scenarios("../features/order_management.feature")


@pytest.fixture
def context() -> dict:
    return {}


@pytest.fixture
def pricing() -> PricingService:
    return PricingService()


@pytest.fixture
def order_service(pricing) -> OrderService:
    return OrderService(pricing)


# ═══════════════════════════════════════════════════════════════
#  Готовый шаг — пример для подражания
# ═══════════════════════════════════════════════════════════════


@given(parsers.parse(
    'Клиент создал заказ с пиццей "{pizza_name}" размера "{size}"'
))
def customer_created_order_with(context, order_service, pizza_name, size):
    customer = Customer(name="Тест", phone="+7")
    order = Order(customer=customer)
    pizza = CATALOG[pizza_name]
    order_service.add_item(order, pizza, PizzaSize(size), 1)
    context["order"] = order


# ═══════════════════════════════════════════════════════════════
#  TODO: реализовать остальные шаги
# ═══════════════════════════════════════════════════════════════

# TODO: @given('Клиент добавил пиццу "{name}" размера "{size}"') — добавление в существующий заказ
# TODO: @given('Клиент оформил и подтвердил заказ на сумму {amount:d} руб.')
# TODO: @when('Клиент удаляет позицию с индексом {index:d}')
# TODO: @when('Клиент отменяет заказ')
# TODO: @then('В заказе остаётся {n:d} позиция') / @then('В заказе остаётся {n:d} позиции')
# TODO: @then('Оставшаяся позиция — "{name}"')
# TODO: @then('Заказ переходит в статус "{status}"')
