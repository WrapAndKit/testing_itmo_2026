## Быстрый старт

```bash
pip install -r requirements.txt
python -m pytest
```

### Пара 5: BDD и Gherkin
- Зачем нужен общий язык между бизнесом и кодом
- Синтаксис Gherkin на русском (Функция / Сценарий / Дано / Когда / Тогда)
- pytest-bdd: связь feature-файлов с Python-кодом
- Контекст между шагами через фикстуру
- Scenario Outline — табличная параметризация
- Когда BDD оправдан, когда антипаттерн

### Пара 6: Property-based + мутационное тестирование
- Слабость example-based тестов
- Hypothesis: стратегии, свойства, shrinking
- Категории свойств: инварианты, сравнения, round-trip, идемпотентность
- assume() для фильтрации
- Мутационное тестирование с Cosmic Ray (кросс-платформенный, в т.ч. Windows)
- Метрика mutation coverage как дополнение к line coverage

## Команды

```bash
# Все тесты
python -m pytest

# Только BDD
python -m pytest tests/bdd/

# Только property-based
python -m pytest tests/property/

# С статистикой Hypothesis
python -m pytest tests/property/ --hypothesis-show-statistics

# Мутационное тестирование (Пара 6) — три шага
cosmic-ray init cosmic-ray.toml session.sqlite
cosmic-ray exec cosmic-ray.toml session.sqlite
cr-report session.sqlite          # текстовый отчёт
cr-html session.sqlite > report.html   # HTML-отчёт
```

### Демо-сценарий для пары: «слабые тесты»

В проекте есть отдельный набор намеренно неполных тестов
(`tests/property_weak/`) и отдельный конфиг `cosmic-ray-weak.toml`.

На основных property-тестах cosmic-ray даёт **0% выживших** —
это нормальная цель. Но для учебной демонстрации нужны живые
мутанты, иначе студентам нечего разбирать.

Слабые тесты проверяют только базовый happy path и пропускают
множество кейсов (разные размеры пиц, промокоды, happy hours,
граничные значения). Mutation score на них — около **45-55%**.

Шаги для демо:

```bash
# 1. Прогон на ПОЛНЫХ тестах — показывает цель
cosmic-ray init cosmic-ray.toml session.sqlite
cosmic-ray exec cosmic-ray.toml session.sqlite
cr-report session.sqlite
# Результат: 0% выживших — отлично

# 2. Прогон на СЛАБЫХ тестах — показывает реальную проблему
cosmic-ray init cosmic-ray-weak.toml weak.sqlite
cosmic-ray exec cosmic-ray-weak.toml weak.sqlite
cr-report weak.sqlite
# Результат: ~140 из 258 выживают (54%)

# 3. HTML-отчёт по слабым тестам — для подробного анализа
cr-html weak.sqlite > weak_report.html

# 4. Студенту:
#    - выбирают одного выжившего мутанта
#    - смотрят, что именно поменялось (diff)
#    - пишут дополнительный тест, который его убьёт
#    - перезапускают cosmic-ray exec — survival rate падает
```
