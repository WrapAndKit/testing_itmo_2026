/**
 * Property-based тесты — Пара 6.
 *
 * Аналог Hypothesis для TypeScript: fast-check.
 *
 * Ключевые соответствия:
 *   pytest + Hypothesis           fast-check
 *   ----------------------         ----------------
 *   @given(...)                    fc.assert(fc.property(...))
 *   st.integers()                  fc.integer()
 *   st.sampled_from(list)          fc.constantFrom(...)
 *   st.lists(stra, min=1)          fc.array(stra, { minLength: 1 })
 *   assume(cond)                   fc.pre(cond)
 *   @composite                     fc.tuple / chain
 */
import * as fc from 'fast-check';

import {
  CATALOG,
  Customer,
  Order,
  OrderItem,
  OrderService,
  PizzaSize,
  PricingService,
  lineTotal,
} from 'src/domain';

// ═══════════════════════════════════════════════════════════════
//  Стратегии — генераторы случайных данных
// ═══════════════════════════════════════════════════════════════

const pizzaName = fc.constantFrom(...Object.keys(CATALOG));
const pizzaSize = fc.constantFrom(...Object.values(PizzaSize));
const quantity = fc.integer({ min: 1, max: 10 });

const orderItem: fc.Arbitrary<OrderItem> = fc.record({
  pizza: pizzaName.map((name) => CATALOG[name]),
  size: pizzaSize,
  quantity,
});

interface OrderOptions {
  isLoyal?: boolean;
  withPromo?: boolean;
}

function arbOrder(opts: OrderOptions = {}): fc.Arbitrary<Order> {
  return fc
    .record({
      isLoyal: opts.isLoyal !== undefined ? fc.constant(opts.isLoyal) : fc.boolean(),
      items: fc.array(orderItem, { minLength: 1, maxLength: 5 }),
      promo: opts.withPromo === false
        ? fc.constant(null)
        : opts.withPromo === true
          ? fc.constantFrom(...Object.keys(PricingService.PROMO_CODES))
          : fc.option(fc.constantFrom(...Object.keys(PricingService.PROMO_CODES)), { nil: null }),
    })
    .map(({ isLoyal, items, promo }) => {
      const customer: Customer = {
        name: 'Test', phone: '+7', isLoyal, ordersCompleted: 0,
      };
      const order = new Order(customer);
      order.items = items;
      order.promoCode = promo;
      return order;
    });
}

// ═══════════════════════════════════════════════════════════════
//  Свойства цены
// ═══════════════════════════════════════════════════════════════

describe('Pricing properties', () => {
  const pricing = new PricingService();
  const midday = new Date(2025, 4, 14, 12, 0);

  test('СВОЙСТВО: итоговая сумма никогда не отрицательна', () => {
    fc.assert(
      fc.property(arbOrder(), (order) => {
        const total = pricing.calculateTotal(order, midday);
        expect(total).toBeGreaterThanOrEqual(0);
      }),
    );
  });

  test('СВОЙСТВО: итог ≤ subtotal + макс. доставка', () => {
    fc.assert(
      fc.property(arbOrder(), (order) => {
        const total = pricing.calculateTotal(order, midday);
        const maxPossible = order.subtotal + PricingService.DELIVERY_FEE;
        expect(total).toBeLessThanOrEqual(maxPossible);
      }),
    );
  });

  test('СВОЙСТВО: без loyal, без промо, не в happy hour — скидок нет', () => {
    fc.assert(
      fc.property(arbOrder({ isLoyal: false, withPromo: false }), (order) => {
        const total = pricing.calculateTotal(order, midday);
        const expectedDelivery =
          order.subtotal >= PricingService.FREE_DELIVERY_THRESHOLD
            ? 0
            : PricingService.DELIVERY_FEE;
        expect(total).toBeCloseTo(order.subtotal + expectedDelivery, 8);
      }),
    );
  });

  test('СВОЙСТВО: для крупных заказов (subtotal >= 1700) loyal платит ≤ обычного', () => {
    // ВНИМАНИЕ! Это поучительный пример. Изначально хотелось проверить:
    // "loyal клиент платит не больше обычного". Но fast-check нашёл случай,
    // когда это НЕ так:
    //   subtotal=1560 (выше порога 1500 → доставка 0)
    //   loyal: 1560*0.9 = 1404 (упало ниже 1500) → +200 доставка = 1604
    //   regular: 1560 + 0 = 1560
    //
    // Это РЕАЛЬНАЯ особенность бизнес-логики: скидка может «опустить»
    // заказ ниже порога бесплатной доставки. Поэтому формулируем
    // свойство строже — для крупных заказов, где порог не пересекается.
    fc.assert(
      fc.property(arbOrder({ isLoyal: true, withPromo: false }), (loyalOrder) => {
        fc.pre(loyalOrder.subtotal >= 1700); // safe margin от порога

        const loyalTotal = pricing.calculateTotal(loyalOrder, midday);

        const regularCustomer: Customer = {
          ...loyalOrder.customer,
          isLoyal: false,
        };
        const regularOrder = new Order(regularCustomer);
        regularOrder.items = [...loyalOrder.items];
        const regularTotal = pricing.calculateTotal(regularOrder, midday);

        expect(loyalTotal).toBeLessThanOrEqual(regularTotal);
      }),
    );
  });
});

// ═══════════════════════════════════════════════════════════════
//  Свойства сервиса заказов
// ═══════════════════════════════════════════════════════════════

describe('OrderService properties', () => {
  const orderService = new OrderService(new PricingService());

  test('СВОЙСТВО: add/remove не меняет состав заказа', () => {
    fc.assert(
      fc.property(
        fc.array(orderItem, { minLength: 1, maxLength: 10 }),
        (items) => {
          const customer: Customer = {
            name: 'X', phone: '+7', isLoyal: false, ordersCompleted: 0,
          };
          const order = new Order(customer);

          for (const item of items) {
            orderService.addItem(order, item.pizza, item.size, item.quantity);
          }
          const countBefore = order.items.length;

          orderService.addItem(order, CATALOG['Маргарита'], PizzaSize.MEDIUM, 1);
          orderService.removeItem(order, order.items.length - 1);

          expect(order.items.length).toBe(countBefore);
        },
      ),
    );
  });

  test('СВОЙСТВО: количество ≤ 0 всегда отклоняется', () => {
    fc.assert(
      fc.property(fc.integer({ max: 0 }), (qty) => {
        const customer: Customer = {
          name: 'X', phone: '+7', isLoyal: false, ordersCompleted: 0,
        };
        const order = new Order(customer);

        expect(() =>
          orderService.addItem(order, CATALOG['Маргарита'], PizzaSize.MEDIUM, qty),
        ).toThrow();
      }),
    );
  });
});

// ═══════════════════════════════════════════════════════════════
//  fc.pre() — отсечение неинтересных случаев (аналог assume)
// ═══════════════════════════════════════════════════════════════

describe('Properties with assumptions', () => {
  const pricing = new PricingService();
  const midday = new Date(2025, 4, 14, 12, 0);

  test('СВОЙСТВО: бесплатная доставка при subtotal >= 1500', () => {
    fc.assert(
      fc.property(arbOrder({ isLoyal: false, withPromo: false }), (order) => {
        // Аналог assume() в Hypothesis
        fc.pre(order.subtotal >= PricingService.FREE_DELIVERY_THRESHOLD);

        const total = pricing.calculateTotal(order, midday);
        expect(total).toBeCloseTo(order.subtotal, 8);
      }),
    );
  });
});

// ═══════════════════════════════════════════════════════════════
//  Свойство стоимости позиции
// ═══════════════════════════════════════════════════════════════

describe('lineTotal properties', () => {
  test('СВОЙСТВО: стоимость позиции всегда положительна', () => {
    fc.assert(
      fc.property(orderItem, (item) => {
        expect(lineTotal(item)).toBeGreaterThan(0);
      }),
    );
  });

  test('СВОЙСТВО: lineTotal линейна по количеству', () => {
    fc.assert(
      fc.property(
        pizzaName,
        pizzaSize,
        fc.integer({ min: 1, max: 5 }),
        fc.integer({ min: 1, max: 5 }),
        (name, size, q1, q2) => {
          const pizza = CATALOG[name];
          const single = lineTotal({ pizza, size, quantity: 1 });
          const total = lineTotal({ pizza, size, quantity: q1 + q2 });
          expect(total).toBeCloseTo(single * (q1 + q2), 8);
        },
      ),
    );
  });
});
