/**
 * Cucumber «World» — контекст одного сценария.
 *
 * Прямой аналог фикстуры `context` из pytest-bdd:
 * Cucumber создаёт новый экземпляр World перед каждым сценарием
 * и автоматически уничтожает его после. Тем самым изоляция тестов
 * обеспечивается на уровне фреймворка.
 *
 * Регистрируется через setWorldConstructor() — Cucumber узнает,
 * какой класс использовать как контекст.
 */
import { setWorldConstructor, World } from '@cucumber/cucumber';

import { Customer, Order, OrderService, PricingService } from 'src/domain';

export class PizzaWorld extends World {
  // Сервисы — создаются один раз на сценарий
  public pricing!: PricingService;
  public orderService!: OrderService;

  // Состояние сценария
  public customer?: Customer;
  public order?: Order;
  public total?: number;
  public moment?: Date;
  public exception?: Error;
  public subtotal?: number;

  // Cucumber передаёт сюда конфиг — игнорируем
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  constructor(options: any) {
    super(options);
    this.pricing = new PricingService();
    this.orderService = new OrderService(this.pricing);
  }
}

setWorldConstructor(PizzaWorld);
