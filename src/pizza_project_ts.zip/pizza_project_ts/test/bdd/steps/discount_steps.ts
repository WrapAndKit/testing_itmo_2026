/**
 * Step definitions для discounts.feature
 * Демонстрирует Scenario Outline — параметризованный сценарий.
 */
import { strict as assert } from 'assert';
import { Given, When, Then } from '@cucumber/cucumber';

import {
  Customer,
  Order,
  PizzaSize,
} from 'src/domain';
import { PizzaWorld } from './world';

// ═══════════════════════════════════════════════════════════════
//  Шаги для Scenario Outline
// ═══════════════════════════════════════════════════════════════

Given('Клиент с признаком {string} оформил заказ на {int} руб.',
  function (this: PizzaWorld, loyalty: string, amount: number) {
    const isLoyal = loyalty.toLowerCase() === 'да';
    const customer: Customer = {
      name: 'Тестовый клиент',
      phone: '+7',
      isLoyal,
      ordersCompleted: 0,
    };
    const order = new Order(customer);

    // Подгоняем сумму через искусственную пиццу
    order.items.push({
      pizza: { name: 'Test Pizza', basePrice: amount, isVegetarian: false },
      size: PizzaSize.MEDIUM,
      quantity: 1,
    });

    this.order = order;
    this.subtotal = amount;
  });

Given('Применил промокод {string}', function (this: PizzaWorld, code: string) {
  if (code.toLowerCase() !== 'нет') {
    this.order!.promoCode = code;
  }
});

Given('Заказ оформлен в {string}', function (this: PizzaWorld, time: string) {
  const [hh, mm] = time.split(':').map(Number);
  this.moment = new Date(2025, 4, 14, hh, mm);
});

When('Рассчитывается итоговая сумма', function (this: PizzaWorld) {
  this.total = this.pricing.calculateTotal(this.order!, this.moment);
});

Then('Применённая скидка составляет {int}%',
  function (this: PizzaWorld, percent: number) {
    const subtotal = this.subtotal!;
    const afterDiscount = subtotal - subtotal * (percent / 100);
    const expectedTotal = afterDiscount >= 1500
      ? afterDiscount
      : afterDiscount + 200;

    assert.equal(
      this.total,
      expectedTotal,
      `Ожидали ${expectedTotal} (скидка ${percent}%), получили ${this.total}`,
    );
  });

// ═══════════════════════════════════════════════════════════════
//  Шаги для обычного сценария — попытка применить плохой промокод
// ═══════════════════════════════════════════════════════════════

When('Клиент пытается применить промокод {string}',
  function (this: PizzaWorld, code: string) {
    try {
      this.orderService.applyPromo(this.order!, code);
    } catch (e) {
      this.exception = e as Error;
    }
  });
