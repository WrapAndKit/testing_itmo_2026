/**
 * Step definitions для order_creation.feature
 *
 * Cucumber.js синтаксис vs pytest-bdd:
 *   pytest-bdd:    @given(parsers.parse('Клиент "{name}" ...'))
 *   cucumber-js:   Given('Клиент {string} создаёт новый заказ', function(name) {...})
 *
 * Параметры в фигурных скобках:
 *   {string}  — строка в кавычках
 *   {int}     — целое число
 *   {float}   — число с плавающей точкой
 *   {word}    — одно слово
 */
import { strict as assert } from 'assert';
import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';

import { CATALOG, Customer, Order, OrderStatus, PizzaSize } from 'src/domain';
import { PizzaWorld } from './world';

setDefaultTimeout(10000);

// ═══════════════════════════════════════════════════════════════
//  GIVEN
// ═══════════════════════════════════════════════════════════════

Given('Клиент {string} создаёт новый заказ', function (this: PizzaWorld, name: string) {
  const customer: Customer = {
    name,
    phone: '+7-000-000-0000',
    isLoyal: false,
    ordersCompleted: 0,
  };
  this.customer = customer;
  this.order = new Order(customer);
});

Given('Зарегистрирован постоянный клиент {string}', function (this: PizzaWorld, name: string) {
  const customer: Customer = {
    name,
    phone: '+7-000-000-0000',
    isLoyal: true,
    ordersCompleted: 20,
  };
  this.customer = customer;
  this.order = new Order(customer);
});

Given('Клиент добавил в заказ пиццу {string} размера {string}',
  function (this: PizzaWorld, pizzaName: string, size: string) {
    const pizza = CATALOG[pizzaName];
    this.orderService.addItem(this.order!, pizza, size as PizzaSize, 1);
  });

Given('Клиент добавил в заказ пиццу {string} размера {string} в количестве {int}',
  function (this: PizzaWorld, pizzaName: string, size: string, qty: number) {
    const pizza = CATALOG[pizzaName];
    this.orderService.addItem(this.order!, pizza, size as PizzaSize, qty);
  });

// ═══════════════════════════════════════════════════════════════
//  WHEN
// ═══════════════════════════════════════════════════════════════

When('Клиент добавляет в заказ пиццу {string} размера {string}',
  function (this: PizzaWorld, pizzaName: string, size: string) {
    const pizza = CATALOG[pizzaName];
    this.orderService.addItem(this.order!, pizza, size as PizzaSize, 1);
  });

When('Клиент добавляет в заказ пиццу {string} размера {string} в количестве {int}',
  function (this: PizzaWorld, pizzaName: string, size: string, qty: number) {
    const pizza = CATALOG[pizzaName];
    this.orderService.addItem(this.order!, pizza, size as PizzaSize, qty);
  });

When('Клиент применяет промокод {string}', function (this: PizzaWorld, code: string) {
  this.orderService.applyPromo(this.order!, code);
});

When('Клиент подтверждает заказ в {int}:{int}',
  function (this: PizzaWorld, hh: number, mm: number) {
    const moment = new Date(2025, 4, 14, hh, mm);
    this.total = this.orderService.confirm(this.order!, moment);
  });

When('Клиент оформляет заказ из пиццы {string} размера {string}',
  function (this: PizzaWorld, pizzaName: string, size: string) {
    const pizza = CATALOG[pizzaName];
    this.orderService.addItem(this.order!, pizza, size as PizzaSize, 1);
  });

When('Клиент пытается подтвердить пустой заказ', function (this: PizzaWorld) {
  try {
    this.orderService.confirm(this.order!);
  } catch (e) {
    this.exception = e as Error;
  }
});

// ═══════════════════════════════════════════════════════════════
//  THEN
// ═══════════════════════════════════════════════════════════════

Then('В заказе должно быть {int} позиции', function (this: PizzaWorld, n: number) {
  assert.equal(this.order!.items.length, n);
});

Then('В заказе должно быть {int} позиций', function (this: PizzaWorld, n: number) {
  assert.equal(this.order!.items.length, n);
});

Then('Сумма заказа без скидок составляет {int} руб.', function (this: PizzaWorld, amount: number) {
  assert.equal(this.order!.subtotal, amount);
});

Then('Сумма к оплате составит {int} руб.', function (this: PizzaWorld, amount: number) {
  assert.equal(this.total, amount);
});

Then('Заказ переходит в статус {string}', function (this: PizzaWorld, status: string) {
  assert.equal(this.order!.status, status as OrderStatus);
});

Then('Применяется скидка постоянного клиента 10%', function (this: PizzaWorld) {
  const subtotal = this.order!.subtotal;
  const expectedAfterDiscount = subtotal * 0.9;
  const expectedTotal = expectedAfterDiscount >= 1500
    ? expectedAfterDiscount
    : expectedAfterDiscount + 200;
  assert.equal(this.total, expectedTotal);
});

Then('Доставка должна быть бесплатной', function (this: PizzaWorld) {
  assert.ok(this.total! <= this.order!.subtotal,
    'Доставка должна быть включена в подытог');
});

Then('К сумме добавляется стоимость доставки {int} руб.',
  function (this: PizzaWorld, _fee: number) {
    assert.ok(this.total! >= this.order!.subtotal,
      'В сумме должна быть доставка');
  });

Then('Система отклоняет операцию с сообщением {string}',
  function (this: PizzaWorld, msg: string) {
    assert.ok(this.exception, 'Ожидалось исключение, но его не было');
    assert.ok(this.exception!.message.includes(msg),
      `Сообщение "${this.exception!.message}" не содержит "${msg}"`);
  });
