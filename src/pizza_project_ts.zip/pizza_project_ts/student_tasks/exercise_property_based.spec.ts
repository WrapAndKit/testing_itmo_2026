/**
 * СТАРТОВЫЙ ФАЙЛ — property-based testing.
 *
 * Задача: написать property-based тесты для пиццерии с fast-check.
 * Эталон: test/property/pricing.property.spec.ts
 *
 * Как запустить:
 *   npx jest student_tasks/exercise_property_based.spec.ts
 *
 * Полезный флаг:
 *   npx jest --verbose
 */
import * as fc from 'fast-check';

import { CATALOG, Customer, Order, PizzaSize, PricingService } from 'src/domain';

const pizzaName = fc.constantFrom(...Object.keys(CATALOG));
const pizzaSize = fc.constantFrom(...Object.values(PizzaSize));


// ══════════════════════════════════════════════════════════════════
//  СВОЙСТВО 1. Промокод не увеличивает сумму
// ══════════════════════════════════════════════════════════════════

describe('Promo never increases total', () => {
  test('TODO: применение промокода не делает заказ дороже', () => {
    /*
    Шаги:
      1. fc.assert(fc.property(pizzaName, pizzaSize, (name, size) => { ... }))
      2. Создать customer (не loyal), order с одной пиццей
      3. Запомнить total без промокода
      4. Применить промокод WELCOME10, посчитать total с промокодом
      5. expect(totalWithPromo).toBeLessThanOrEqual(totalWithoutPromo)
    */
    expect(true).toBe(true); // заменить
  });
});


// ══════════════════════════════════════════════════════════════════
//  СВОЙСТВО 2. Положительная стоимость для непустого заказа
// ══════════════════════════════════════════════════════════════════

describe('Total is always positive', () => {
  test('TODO: для непустого заказа total > 0', () => {
    /*
    Шаги:
      1. fc.assert(fc.property(fc.integer({ min: 1, max: 5 }), (count) => { ... }))
      2. Создать заказ с count позициями
      3. Посчитать total
      4. expect(total).toBeGreaterThan(0)
    */
    expect(true).toBe(true);
  });
});


// ══════════════════════════════════════════════════════════════════
//  СВОЙСТВО 3. Бесплатная доставка с порога
// ══════════════════════════════════════════════════════════════════

describe('Free delivery at threshold', () => {
  test('TODO: при subtotal >= 1500 доставка обнуляется', () => {
    /*
    Используйте fc.pre() для отсечения случаев < 1500.
    */
    expect(true).toBe(true);
  });
});
