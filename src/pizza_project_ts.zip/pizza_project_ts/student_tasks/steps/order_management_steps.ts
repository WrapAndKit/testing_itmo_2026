/**
 * СТАРТОВЫЙ ФАЙЛ — BDD
 *
 * Задача: дописать step definitions для
 * student_tasks/features/order_management.feature
 *
 * Эталон: test/bdd/steps/order_creation_steps.ts
 *
 * Как запустить:
 *   npx cucumber-js --profile student
 */
import { strict as assert } from 'assert';
import { Given, When, Then, setWorldConstructor, World } from '@cucumber/cucumber';

import { CATALOG, Customer, Order, OrderStatus, PizzaSize, OrderService, PricingService } from 'src/domain';


// ═══════════════════════════════════════════════════════════════
//  Контекст сценария
// ═══════════════════════════════════════════════════════════════

class StudentWorld extends World {
  public pricing!: PricingService;
  public orderService!: OrderService;
  public order?: Order;
  public exception?: Error;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  constructor(options: any) {
    super(options);
    this.pricing = new PricingService();
    this.orderService = new OrderService(this.pricing);
  }
}
setWorldConstructor(StudentWorld);


// ═══════════════════════════════════════════════════════════════
//  Готовый шаг — пример для подражания
// ═══════════════════════════════════════════════════════════════

Given('Клиент создал заказ с пиццей {string} размера {string}',
  function (this: StudentWorld, pizzaName: string, size: string) {
    const customer: Customer = {
      name: 'Тест', phone: '+7', isLoyal: false, ordersCompleted: 0,
    };
    const order = new Order(customer);
    const pizza = CATALOG[pizzaName];
    this.orderService.addItem(order, pizza, size as PizzaSize, 1);
    this.order = order;
  });


// ═══════════════════════════════════════════════════════════════
//  TODO: реализовать остальные шаги
// ═══════════════════════════════════════════════════════════════

// TODO: Given('Клиент добавил пиццу {string} размера {string}', ...) — добавляет в существующий заказ
// TODO: Given('Клиент оформил и подтвердил заказ на сумму {int} руб.', ...)

// TODO: When('Клиент удаляет позицию с индексом {int}', ...)
// TODO: When('Клиент отменяет заказ', ...)

// TODO: Then('В заказе остаётся {int} позиция', ...)
// TODO: Then('В заказе остаётся {int} позиции', ...)
// TODO: Then('Оставшаяся позиция — {string}', ...)
// TODO: Then('Заказ переходит в статус {string}', ...)
// TODO: Then('Система отклоняет операцию с сообщением {string}', ...)
