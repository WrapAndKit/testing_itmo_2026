/**
 * Бизнес-домен «Пиццерия»
 */

export enum PizzaSize {
  SMALL = 'SMALL',
  MEDIUM = 'MEDIUM',
  LARGE = 'LARGE',
}

export enum OrderStatus {
  DRAFT = 'DRAFT',
  CONFIRMED = 'CONFIRMED',
  COOKING = 'COOKING',
  READY = 'READY',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED',
}

export interface Pizza {
  readonly name: string;
  readonly basePrice: number;       // цена за MEDIUM
  readonly isVegetarian: boolean;
}

export interface OrderItem {
  pizza: Pizza;
  size: PizzaSize;
  quantity: number;
}

export function lineTotal(item: OrderItem): number {
  const sizeMultipliers: Record<PizzaSize, number> = {
    [PizzaSize.SMALL]: 0.8,
    [PizzaSize.MEDIUM]: 1.0,
    [PizzaSize.LARGE]: 1.3,
  };
  return item.pizza.basePrice * sizeMultipliers[item.size] * item.quantity;
}

export interface Customer {
  name: string;
  phone: string;
  isLoyal: boolean;
  ordersCompleted: number;
}

export class Order {
  public items: OrderItem[] = [];
  public status: OrderStatus = OrderStatus.DRAFT;
  public promoCode: string | null = null;
  public readonly createdAt: Date = new Date();

  constructor(public readonly customer: Customer) {}

  get subtotal(): number {
    return this.items.reduce((sum, item) => sum + lineTotal(item), 0);
  }

  get isEmpty(): boolean {
    return this.items.length === 0;
  }
}

// ═════════════════════════════════════════════════════════════════
//  Сервис расчёта стоимости
// ═════════════════════════════════════════════════════════════════

export class PricingService {
  static readonly DELIVERY_FEE = 200;
  static readonly FREE_DELIVERY_THRESHOLD = 1500;
  static readonly LOYAL_DISCOUNT = 0.10;
  static readonly HAPPY_HOUR_DISCOUNT = 0.15;

  static readonly PROMO_CODES: Record<string, number> = {
    WELCOME10: 0.10,
    SUMMER20: 0.20,
    VIP30: 0.30,
  };

  /**
   * Итог = subtotal − лучшая скидка + доставка (если применима).
   * Применяется максимум одна (самая выгодная) скидка.
   */
  calculateTotal(order: Order, now: Date = new Date()): number {
    if (order.isEmpty) {
      throw new Error('Невозможно рассчитать стоимость пустого заказа');
    }

    const subtotal = order.subtotal;

    // Подбираем лучшую скидку
    let bestDiscount = 0;

    if (order.customer.isLoyal) {
      bestDiscount = Math.max(bestDiscount, PricingService.LOYAL_DISCOUNT);
    }

    if (order.promoCode && order.promoCode in PricingService.PROMO_CODES) {
      bestDiscount = Math.max(bestDiscount, PricingService.PROMO_CODES[order.promoCode]);
    }

    const hour = now.getHours();
    if (hour >= 14 && hour < 17) {
      bestDiscount = Math.max(bestDiscount, PricingService.HAPPY_HOUR_DISCOUNT);
    }

    const afterDiscount = subtotal - subtotal * bestDiscount;

    const delivery = afterDiscount >= PricingService.FREE_DELIVERY_THRESHOLD
      ? 0
      : PricingService.DELIVERY_FEE;

    return afterDiscount + delivery;
  }
}

// ═════════════════════════════════════════════════════════════════
//  Сервис управления заказами
// ═════════════════════════════════════════════════════════════════

export class OrderService {
  constructor(private readonly pricing: PricingService) {}

  addItem(order: Order, pizza: Pizza, size: PizzaSize, quantity = 1): void {
    if (quantity <= 0) {
      throw new Error('Количество должно быть положительным');
    }
    if (order.status !== OrderStatus.DRAFT) {
      throw new Error(`Нельзя изменить заказ в статусе ${order.status}`);
    }
    order.items.push({ pizza, size, quantity });
  }

  removeItem(order: Order, index: number): void {
    if (order.status !== OrderStatus.DRAFT) {
      throw new Error('Нельзя изменить подтверждённый заказ');
    }
    if (index < 0 || index >= order.items.length) {
      throw new Error(`Нет позиции с индексом ${index}`);
    }
    order.items.splice(index, 1);
  }

  applyPromo(order: Order, code: string): void {
    if (order.status !== OrderStatus.DRAFT) {
      throw new Error('Промокод можно применить только к черновику');
    }
    if (!(code in PricingService.PROMO_CODES)) {
      throw new Error(`Неизвестный промокод: ${code}`);
    }
    order.promoCode = code;
  }

  confirm(order: Order, now: Date = new Date()): number {
    if (order.isEmpty) {
      throw new Error('Нельзя подтвердить пустой заказ');
    }
    if (order.status !== OrderStatus.DRAFT) {
      throw new Error(`Заказ уже в статусе ${order.status}`);
    }
    const total = this.pricing.calculateTotal(order, now);
    order.status = OrderStatus.CONFIRMED;
    return total;
  }

  cancel(order: Order): void {
    if (order.status === OrderStatus.DELIVERED || order.status === OrderStatus.CANCELLED) {
      throw new Error(`Нельзя отменить заказ в статусе ${order.status}`);
    }
    order.status = OrderStatus.CANCELLED;
  }
}

// ═════════════════════════════════════════════════════════════════
//  Каталог пицц
// ═════════════════════════════════════════════════════════════════

export const MARGHERITA: Pizza = {
  name: 'Маргарита', basePrice: 450, isVegetarian: true,
};
export const PEPPERONI: Pizza = {
  name: 'Пепперони', basePrice: 550, isVegetarian: false,
};
export const QUATTRO_FORMAGGI: Pizza = {
  name: 'Четыре сыра', basePrice: 650, isVegetarian: true,
};
export const HAWAIIAN: Pizza = {
  name: 'Гавайская', basePrice: 600, isVegetarian: false,
};

export const CATALOG: Record<string, Pizza> = {
  'Маргарита': MARGHERITA,
  'Пепперони': PEPPERONI,
  'Четыре сыра': QUATTRO_FORMAGGI,
  'Гавайская': HAWAIIAN,
};
