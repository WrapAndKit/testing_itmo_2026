module.exports = {
  default: {
    requireModule: ['ts-node/register', 'tsconfig-paths/register'],
    require: ['test/bdd/steps/**/*.ts'],
    paths: ['test/bdd/features/**/*.feature'],
    format: ['progress', 'summary'],
    publishQuiet: true,
  },
  student: {
    requireModule: ['ts-node/register', 'tsconfig-paths/register'],
    require: ['student_tasks/steps/**/*.ts'],
    paths: ['student_tasks/features/**/*.feature'],
    format: ['progress', 'summary'],
    publishQuiet: true,
  },
};
