## Быстрый старт

```bash
npm install
npm test
```
## Стек

- **Cucumber.js** — BDD на естественном языке (Gherkin), близок к pytest-bdd
- **Jest** — для property-based тестов (как и в Пары 3-4)
- **fast-check** — property-based фреймворк (де-факто стандарт в JS/TS)
- **Stryker** — мутационное тестирование


## Аналогии Python ↔ TypeScript

| pytest-bdd | Cucumber.js |
|------------|-------------|
| `@given(parsers.parse('...'))` | `Given('...', function() {})` |
| `{name}` в parsers | `{string}` в Cucumber |
| `{count:d}` | `{int}` |
| Фикстура `context` (dict) | World class + `setWorldConstructor()` |
| `scenarios("../features/...")` | `cucumber.js` config с paths |

| Hypothesis | fast-check |
|------------|------------|
| `@given(st.integers())` | `fc.assert(fc.property(fc.integer(), ...))` |
| `st.sampled_from(list)` | `fc.constantFrom(...list)` |
| `st.lists(s, min_size=1)` | `fc.array(s, { minLength: 1 })` |
| `assume(cond)` | `fc.pre(cond)` |
| `@composite` | `fc.record({...})` или `.chain(...)` |

| mutmut | Stryker |
|--------|---------|
| `mutmut run` | `npx stryker run` |
| `mutmut results` | HTML отчёт автоматически |
| `mutmut show <id>` | В HTML — diff и информация |

## Команды

```bash
# Все тесты
npm test

# Только BDD
npm run test:bdd

# Только property
npm run test:property

# С watch
npm run test:property:watch

# Мутационное тестирование
npx stryker run

# Стартовый файл (Пара 5)
npx cucumber-js --profile student

# Стартовый файл (Пара 6)
npx jest student_tasks/exercise_property_based.spec.ts
```
