
## Предметная область

REST API для работы с биржевыми датами:
- Календари 4 бирж: MOEX, NYSE, LSE, TSE (с реальными праздниками)
- T+N расчёт с учётом выходных и праздников
- Конвенции корректировки дат (FOLLOWING, MODIFIED_FOLLOWING, PRECEDING, MODIFIED_PRECEDING)
- Day-count конвенции (ACT/360, ACT/365, 30/360)
- Статус биржи с учётом таймзон и DST
- SettlementService для расчёта инструкций по сделкам (зависит от внешнего провайдера курсов — материал для моков)

---

## Быстрый старт

```bash
# Установка
pip install -r requirements.txt

# Запуск всех тестов
python -m pytest

# Ожидается: 142 passed, покрытие ~94%
```

**Концепции:**
- Зачем нужны моки — изоляция от внешних систем
- `unittest.mock.MagicMock(spec=Class)` — типобезопасные моки
- `return_value` — простая замена возвращаемого значения
- `side_effect` как функция — разные значения для разных входов
- `side_effect` как исключение — имитация сбоев
- `side_effect` как список — последовательность ответов
- `assert_called_once_with`, `assert_not_called` — проверка вызовов
- `call_count`, `call_args`, `assert_has_calls` — продвинутая инспекция

**Файлы с примерами:** `tests/unit/test_services.py`

**Концепции:**
- FastAPI `TestClient` вместо реального HTTP
- GET/POST с `client.get(...)` / `client.post(..., json=...)`
- Проверка `response.status_code` и `response.json()`
- Параметризация матриц: разные биржи × разные даты
- `app.dependency_overrides` для подмены зависимостей
- Cleanup через `yield` + `clear()`
- Тестирование валидации Pydantic (422)
- OpenAPI-схема как объект тестирования

**Файлы с примерами:** `tests/api/test_endpoints.py`, `tests/api/conftest.py`

Чтобы посмотреть API вживую (необязательно для тестов):

```bash
cd trading_project
uvicorn trading_api.main:app --reload --app-dir src
```

Потом открыть http://localhost:8000/docs — интерактивная Swagger-документация.

---

## Полезные команды

```bash
# Все тесты
python -m pytest

# Только юниты 
python -m pytest tests/unit/

# Только API 
python -m pytest tests/api/

# Главный файл про моки
python -m pytest tests/unit/test_services.py -v

# С покрытием
python -m pytest --cov=src --cov-branch --cov-report=term-missing

# Только smoke
python -m pytest -m smoke

# Только упражнения студентов
python -m pytest student_tasks/
```

---

## Особенности предметной области

### Почему именно биржа?

- **Много граничных случаев** — переходы через выходные, праздники, концы месяцев
- **Таймзоны** — биржа в Токио работает, когда в Нью-Йорке ночь
- **DST** — регулярная ловушка в США и Европе
- **Реальные зависимости** — провайдер курсов = повод для моков
- **Сложная, но понятная бизнес-логика** — студенты из ИТ обычно знакомы с концепциями

### Почему захардкоженные календари?

- Нет зависимости от БД — чище пример
- Праздники настоящие (можно сверить с сайтом биржи)
- Легко добавить свой тестовый календарь — для изолированных тестов

### Почему учитываем таймзоны?

- В реальности API всегда получает UTC
- Ответ — в локальном времени биржи
- Переходы через день между зонами — классический баг
