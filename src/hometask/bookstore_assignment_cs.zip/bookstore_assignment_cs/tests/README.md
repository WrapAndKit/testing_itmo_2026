# Тесты

Разложите тесты по видам, например:

```
tests/
├── Bookstore.Tests.Unit/         модульные тесты PricingService
├── Bookstore.Tests.Mocks/        тесты сервисов с подменой зависимостей
├── Bookstore.Tests.Api/          тесты HTTP API
└── Bookstore.Tests.Property/     тесты на основе свойств
```

Помимо этого, в случае нахождения бага нужно составить баг-репорт.
