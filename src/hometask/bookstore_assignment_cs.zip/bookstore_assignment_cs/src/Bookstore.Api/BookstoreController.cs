using System.ComponentModel.DataAnnotations;
using Bookstore;
using Bookstore.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bookstore.Api;

// --- DTO для входящих запросов ---

public sealed class CreateOrderRequest
{
    [Required, MinLength(1)]
    public string CustomerId { get; set; } = "";
}

public sealed class AddItemRequest
{
    [Required, MinLength(10)]
    public string Isbn { get; set; } = "";

    [Range(1, 100)]
    public int Quantity { get; set; }
}

public sealed class ApplyPromoRequest
{
    [Required, MinLength(2)]
    public string Code { get; set; } = "";
}

public sealed class AddressDto
{
    [Required, MinLength(2)]
    public string Country { get; set; } = "";

    [Required]
    public string City { get; set; } = "";

    [Required]
    public string PostalCode { get; set; } = "";

    [Required]
    public string Street { get; set; } = "";
}

public sealed class CheckoutRequest
{
    [Required]
    public AddressDto ShippingAddress { get; set; } = new();
}

// --- Представления для исходящих ответов ---

public sealed record OrderResponse(
    string OrderId,
    string Status,
    string CustomerId,
    int ItemsCount,
    decimal Subtotal,
    string? PromoCode);

public sealed record CheckoutResponse(
    string OrderId,
    string Status,
    decimal Total,
    string TransactionId);

// --- Контроллер ---

/// <summary>HTTP-эндпоинты для управления заказами.</summary>
[ApiController]
[Route("")]
public sealed class BookstoreController : ControllerBase
{
    private readonly OrderService _orderService;
    private readonly Dictionary<string, Order> _orders;
    private readonly Dictionary<string, Customer> _customers;

    public BookstoreController(
        OrderService orderService,
        Dictionary<string, Order> orders,
        Dictionary<string, Customer> customers)
    {
        _orderService = orderService;
        _orders = orders;
        _customers = customers;
    }

    private static OrderResponse ToResponse(Order order) => new(
        order.OrderId,
        order.Status.ToString(),
        order.Customer.CustomerId,
        order.Items.Count,
        order.Subtotal,
        order.PromoCode);

    private IActionResult Problem(int code, string detail)
        => StatusCode(code, new { detail });

    [HttpPost("orders")]
    public IActionResult CreateOrder([FromBody] CreateOrderRequest body)
    {
        if (!_customers.TryGetValue(body.CustomerId, out var customer))
        {
            return Problem(404, $"Покупатель {body.CustomerId} не найден");
        }
        try
        {
            var order = _orderService.CreateOrder(customer);
            _orders[order.OrderId] = order;
            return StatusCode(201, ToResponse(order));
        }
        catch (OrderException e)
        {
            return Problem(403, e.Message);
        }
    }

    [HttpGet("orders/{orderId}")]
    public IActionResult GetOrder(string orderId)
    {
        if (!_orders.TryGetValue(orderId, out var order))
        {
            return Problem(404, $"Заказ {orderId} не найден");
        }
        return Ok(ToResponse(order));
    }

    [HttpPost("orders/{orderId}/items")]
    public IActionResult AddItem(string orderId, [FromBody] AddItemRequest body)
    {
        if (!_orders.TryGetValue(orderId, out var order))
        {
            return Problem(404, $"Заказ {orderId} не найден");
        }
        try
        {
            _orderService.AddItem(order, body.Isbn, body.Quantity);
        }
        catch (BookNotFoundException e)
        {
            return Problem(404, e.Message);
        }
        catch (InvalidOrderStateException e)
        {
            return Problem(409, e.Message);
        }
        catch (OrderException e)
        {
            return Problem(400, e.Message);
        }
        return Ok(ToResponse(order));
    }

    [HttpDelete("orders/{orderId}/items/{isbn}")]
    public IActionResult RemoveItem(string orderId, string isbn)
    {
        if (!_orders.TryGetValue(orderId, out var order))
        {
            return Problem(404, $"Заказ {orderId} не найден");
        }
        try
        {
            _orderService.RemoveItem(order, isbn);
        }
        catch (InvalidOrderStateException e)
        {
            return Problem(409, e.Message);
        }
        return Ok(ToResponse(order));
    }

    [HttpPost("orders/{orderId}/promo")]
    public IActionResult ApplyPromo(string orderId, [FromBody] ApplyPromoRequest body)
    {
        if (!_orders.TryGetValue(orderId, out var order))
        {
            return Problem(404, $"Заказ {orderId} не найден");
        }
        try
        {
            _orderService.ApplyPromoCode(order, body.Code);
        }
        catch (InvalidOrderStateException e)
        {
            return Problem(409, e.Message);
        }
        return Ok(ToResponse(order));
    }

    [HttpPost("orders/{orderId}/checkout")]
    public IActionResult Checkout(string orderId, [FromBody] CheckoutRequest body)
    {
        if (!_orders.TryGetValue(orderId, out var order))
        {
            return Problem(404, $"Заказ {orderId} не найден");
        }
        var address = new Address(
            body.ShippingAddress.Country,
            body.ShippingAddress.City,
            body.ShippingAddress.PostalCode,
            body.ShippingAddress.Street);
        try
        {
            var result = _orderService.Checkout(order, address);
            return Ok(new CheckoutResponse(
                result.Order.OrderId,
                result.Order.Status.ToString(),
                result.Total,
                result.PaymentTransactionId));
        }
        catch (InvalidOrderStateException e)
        {
            return Problem(409, e.Message);
        }
        catch (PricingException e)
        {
            return Problem(422, e.Message);
        }
        catch (InventoryException e)
        {
            return Problem(409, e.Message);
        }
        catch (PaymentDeclinedException e)
        {
            return Problem(402, e.Message);
        }
        catch (PaymentException e)
        {
            return Problem(502, e.Message);
        }
    }

    [HttpPost("orders/{orderId}/cancel")]
    public IActionResult Cancel(string orderId)
    {
        if (!_orders.TryGetValue(orderId, out var order))
        {
            return Problem(404, $"Заказ {orderId} не найден");
        }
        try
        {
            _orderService.Cancel(order);
        }
        catch (InvalidOrderStateException e)
        {
            return Problem(409, e.Message);
        }
        return Ok(ToResponse(order));
    }
}
