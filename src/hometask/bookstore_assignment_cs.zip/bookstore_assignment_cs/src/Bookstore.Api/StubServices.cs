using Bookstore.Interfaces;
using Bookstore.Models;

namespace Bookstore.Api;

// Заглушки реализаций зависимостей. Регистрируются по умолчанию и бросают
// ошибку при первом вызове любого метода. В тестах подменяются на тестовые
// двойники, в демо-режиме — на in-memory реализации из DemoSetup.

public sealed class StubBookRepository : IBookRepository
{
    public Book GetByIsbn(string isbn) =>
        throw new InvalidOperationException("Реализация IBookRepository не подключена");

    public IReadOnlyList<Book> Search(string query, int limit = 20) =>
        throw new InvalidOperationException("Реализация IBookRepository не подключена");
}

public sealed class StubInventoryService : IInventoryService
{
    public int GetStock(string isbn) =>
        throw new InvalidOperationException("Реализация IInventoryService не подключена");

    public string Reserve(string isbn, int quantity) =>
        throw new InvalidOperationException("Реализация IInventoryService не подключена");

    public void Release(string reservationId) =>
        throw new InvalidOperationException("Реализация IInventoryService не подключена");
}

public sealed class StubPaymentGateway : IPaymentGateway
{
    public PaymentResult Charge(string customerId, decimal amount, string currency, string idempotencyKey) =>
        throw new InvalidOperationException("Реализация IPaymentGateway не подключена");

    public PaymentResult Refund(string transactionId, decimal amount) =>
        throw new InvalidOperationException("Реализация IPaymentGateway не подключена");
}

public sealed class StubNotificationService : INotificationService
{
    public void SendOrderConfirmation(Customer customer, Order order) =>
        throw new InvalidOperationException("Реализация INotificationService не подключена");

    public void SendShippingNotification(Customer customer, Order order, string trackingNumber) =>
        throw new InvalidOperationException("Реализация INotificationService не подключена");
}

public sealed class StubClock : IClock
{
    public DateTime Now() =>
        throw new InvalidOperationException("Реализация IClock не подключена");
}
