using System.Collections.Concurrent;
using Bookstore.Interfaces;
using Bookstore.Models;

namespace Bookstore.Api;

// Демонстрационные реализации зависимостей в памяти.
// Подключаются при запуске с переменной окружения BOOKSTORE_DEMO=1.

internal sealed class InMemoryBookRepository : IBookRepository
{
    public static readonly IReadOnlyDictionary<string, Book> Catalog =
        new Dictionary<string, Book>
        {
            ["978-5-0010-0001-1"] = new(
                "978-5-0010-0001-1", "Чистый код", "Роберт Мартин",
                BookCategory.NON_FICTION, 1500m, 600, 2019),
            ["978-5-0010-0002-2"] = new(
                "978-5-0010-0002-2", "Высшая математика", "А. Иванов",
                BookCategory.TEXTBOOK, 900m, 800, 2021),
            ["978-5-0010-0003-3"] = new(
                "978-5-0010-0003-3", "Сказки на ночь", "М. Петрова",
                BookCategory.CHILDREN, 500m, 300, 2020),
            ["978-5-0010-0004-4"] = new(
                "978-5-0010-0004-4", "Первое издание", "Редкий Автор",
                BookCategory.RARE, 12000m, 1200, 1965),
            ["978-5-0010-0005-5"] = new(
                "978-5-0010-0005-5", "Война и мир", "Л. Толстой",
                BookCategory.FICTION, 800m, 1400, 2018),
        };

    public Book GetByIsbn(string isbn)
    {
        if (!Catalog.TryGetValue(isbn, out var book))
        {
            throw new BookNotFoundException($"Книга {isbn} не найдена");
        }
        return book;
    }

    public IReadOnlyList<Book> Search(string query, int limit = 20)
    {
        var q = query.ToLowerInvariant();
        return Catalog.Values
            .Where(b => b.Title.ToLowerInvariant().Contains(q)
                     || b.Author.ToLowerInvariant().Contains(q))
            .Take(limit)
            .ToList();
    }
}

internal sealed class InMemoryInventory : IInventoryService
{
    private readonly ConcurrentDictionary<string, int> _stock = new();
    private readonly ConcurrentDictionary<string, (string Isbn, int Quantity)> _reservations = new();
    private int _counter;

    public InMemoryInventory()
    {
        foreach (var isbn in InMemoryBookRepository.Catalog.Keys)
        {
            _stock[isbn] = 100;
        }
    }

    public int GetStock(string isbn) => _stock.GetValueOrDefault(isbn, 0);

    public string Reserve(string isbn, int quantity)
    {
        var available = _stock.GetValueOrDefault(isbn, 0);
        if (available < quantity)
        {
            throw new InventoryException($"Недостаточно товара {isbn}");
        }
        _stock[isbn] = available - quantity;
        var id = $"RES-{Interlocked.Increment(ref _counter)}";
        _reservations[id] = (isbn, quantity);
        return id;
    }

    public void Release(string reservationId)
    {
        if (_reservations.TryRemove(reservationId, out var entry))
        {
            _stock.AddOrUpdate(entry.Isbn, entry.Quantity, (_, v) => v + entry.Quantity);
        }
    }
}

internal sealed class FakePaymentGateway : IPaymentGateway
{
    private int _counter;

    public PaymentResult Charge(string customerId, decimal amount, string currency, string idempotencyKey)
        => new(PaymentStatus.SUCCESS, $"TX-{Interlocked.Increment(ref _counter)}");

    public PaymentResult Refund(string transactionId, decimal amount)
        => new(PaymentStatus.SUCCESS, $"RF-{Interlocked.Increment(ref _counter)}");
}

internal sealed class ConsoleNotifications : INotificationService
{
    public void SendOrderConfirmation(Customer customer, Order order)
        => Console.WriteLine($"[notify] Заказ {order.OrderId} подтверждён для {customer.Email}");

    public void SendShippingNotification(Customer customer, Order order, string trackingNumber)
        => Console.WriteLine($"[notify] Заказ {order.OrderId} отправлен, трек {trackingNumber}");
}

internal sealed class SystemClock : IClock
{
    public DateTime Now() => DateTime.Now;
}

internal static class DemoSetup
{
    /// <summary>
    /// Зарегистрировать in-memory реализации и засеять тестового покупателя.
    /// </summary>
    public static void Configure(
        IServiceCollection services,
        Dictionary<string, Customer> customersDb)
    {
        services.AddSingleton<IBookRepository, InMemoryBookRepository>();
        services.AddSingleton<IInventoryService, InMemoryInventory>();
        services.AddSingleton<IPaymentGateway, FakePaymentGateway>();
        services.AddSingleton<INotificationService, ConsoleNotifications>();
        services.AddSingleton<IClock, SystemClock>();

        customersDb["demo"] = new Customer
        {
            CustomerId = "demo",
            Name = "Демо Покупатель",
            Email = "demo@example.com",
            Tier = CustomerTier.SILVER,
        };
    }
}
