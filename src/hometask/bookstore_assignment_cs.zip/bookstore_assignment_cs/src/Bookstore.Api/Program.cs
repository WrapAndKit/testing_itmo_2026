using System.Text.Json;
using System.Text.Json.Serialization;
using Bookstore;
using Bookstore.Api;
using Bookstore.Interfaces;
using Bookstore.Models;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

// Конфигурация JSON: snake_case для полей, enum-значения как имена (DRAFT,
// PENDING_PAYMENT и т.д.), чтобы формат совпадал с описанием в ТЗ.
builder.Services.AddControllers()
    .AddJsonOptions(opts =>
    {
        opts.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower;
        opts.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.SnakeCaseLower;
        opts.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

// Ошибки валидации модели возвращать как 422, а не 400, чтобы совпадало с
// поведением FastAPI/NestJS-версий проекта.
builder.Services.Configure<ApiBehaviorOptions>(opts =>
{
    opts.InvalidModelStateResponseFactory = context =>
    {
        var errors = context.ModelState
            .Where(kvp => kvp.Value is not null && kvp.Value.Errors.Count > 0)
            .ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value!.Errors.Select(e => e.ErrorMessage).ToArray());
        return new ObjectResult(new { detail = "Ошибки валидации", errors })
        {
            StatusCode = StatusCodes.Status422UnprocessableEntity,
        };
    };
});

// Хранилища заказов и покупателей. В реальной системе — база данных.
var ordersDb = new Dictionary<string, Order>();
var customersDb = new Dictionary<string, Customer>();
builder.Services.AddSingleton(ordersDb);
builder.Services.AddSingleton(customersDb);

// Внешние зависимости: по умолчанию — заглушки, бросающие ошибку при первом
// вызове. В демо-режиме подменяются реализациями в памяти.
var isDemoMode = Environment.GetEnvironmentVariable("BOOKSTORE_DEMO") == "1";
if (isDemoMode)
{
    DemoSetup.Configure(builder.Services, customersDb);
}
else
{
    builder.Services.AddSingleton<IBookRepository, StubBookRepository>();
    builder.Services.AddSingleton<IInventoryService, StubInventoryService>();
    builder.Services.AddSingleton<IPaymentGateway, StubPaymentGateway>();
    builder.Services.AddSingleton<INotificationService, StubNotificationService>();
    builder.Services.AddSingleton<IClock, StubClock>();
}

builder.Services.AddScoped<OrderService>();

// Swagger UI для интерактивного знакомства с API.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Bookstore API", Version = "1.0" });
});

var app = builder.Build();
app.MapControllers();

// Swagger доступен в обоих режимах: путь /docs (вместо стандартного /swagger).
app.UseSwagger(c => c.RouteTemplate = "docs/{documentName}/swagger.json");
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/docs/v1/swagger.json", "Bookstore API v1");
    c.RoutePrefix = "docs";
});

if (isDemoMode)
{
    var sampleIsbns = InMemoryBookRepository.Catalog.Keys.ToArray();
    // Корневой адрес перенаправляет на Swagger UI.
    app.MapGet("/", () => Results.Redirect("/docs"));
    Console.WriteLine("Демо-режим. Swagger UI: http://localhost:5000/docs (или см. порт ASP.NET Core).");
    Console.WriteLine("Покупатель: demo. Примеры ISBN: " + string.Join(", ", sampleIsbns));
}

app.Run();

// Для возможного использования с WebApplicationFactory<Program> в тестах.
public partial class Program { }
