using Bookstore.Models;

namespace Bookstore;

/// <summary>Детализация итоговой стоимости заказа по составляющим.</summary>
public sealed record PriceBreakdown(
    decimal Subtotal,
    decimal DiscountableSubtotal,
    decimal NonDiscountableSubtotal,
    decimal DiscountRate,
    decimal DiscountAmount,
    decimal SubtotalAfterDiscount,
    decimal DeliveryFee,
    decimal Vat,
    decimal Total);

/// <summary>Расчёт стоимости заказа: скидки, доставка и налог.</summary>
public class PricingService
{
    // Скидка по уровню покупателя.
    public static readonly IReadOnlyDictionary<CustomerTier, decimal> TierDiscounts =
        new Dictionary<CustomerTier, decimal>
        {
            [CustomerTier.BRONZE] = 0.00m,
            [CustomerTier.SILVER] = 0.05m,
            [CustomerTier.GOLD] = 0.10m,
        };

    // Доступные промокоды и их скидка.
    public static readonly IReadOnlyDictionary<string, decimal> PromoCodes =
        new Dictionary<string, decimal>
        {
            ["WELCOME15"] = 0.15m,
            ["SUMMER20"] = 0.20m,
            ["STUDENT25"] = 0.25m,
        };

    // Промокод STUDENT25 действует только на учебники.
    public const BookCategory StudentPromoCategory = BookCategory.TEXTBOOK;

    // Доставка.
    public const decimal BaseDeliveryFee = 300m;
    public const decimal FreeDeliveryThreshold = 3000m;
    public const decimal DeliveryPer100GramsOver1Kg = 1m;

    // НДС на книги.
    public const decimal VatRate = 0.10m;

    // Ограничения заказа.
    public const int MaxQuantityPerItem = 20;
    public const decimal OrderLimitGold = 500_000m;
    public const decimal OrderLimitRegular = 100_000m;

    // Период распродажи «чёрная пятница» (включительно) и её скидка.
    public static readonly (int Month, int Day) BlackFridayStart = (11, 24);
    public static readonly (int Month, int Day) BlackFridayEnd = (11, 30);
    public const decimal BlackFridayDiscount = 0.30m;

    /// <summary>Посчитать полную стоимость заказа с разбивкой по составляющим.</summary>
    public PriceBreakdown CalculateOrderTotal(Order order, DateTime? moment = null)
    {
        ValidateOrder(order);
        var at = moment ?? DateTime.Now;

        var discountable = DiscountableSubtotal(order.Items);
        var nonDiscountable = NonDiscountableSubtotal(order.Items);
        var subtotal = discountable + nonDiscountable;

        var discountRate = BestDiscountRate(order, at);
        var discountAmount = Math.Round(discountable * discountRate, 2);
        var subtotalAfterDiscount = subtotal - discountAmount;

        var deliveryFee = CalculateDeliveryFee(order.Items, subtotalAfterDiscount);
        var vat = CalculateVat(subtotalAfterDiscount);
        var total = subtotalAfterDiscount + deliveryFee + vat;

        return new PriceBreakdown(
            subtotal,
            discountable,
            nonDiscountable,
            discountRate,
            discountAmount,
            subtotalAfterDiscount,
            deliveryFee,
            vat,
            total);
    }

    /// <summary>
    /// Выбрать наибольшую из применимых скидок: по уровню, по промокоду и по
    /// распродаже.
    /// </summary>
    public decimal BestDiscountRate(Order order, DateTime moment)
    {
        var tierDiscount = TierDiscounts[order.Customer.Tier];
        var promoDiscount = ApplicablePromoDiscount(order.PromoCode, order.Items);
        var blackFriday = IsBlackFriday(moment) ? BlackFridayDiscount : 0m;
        return Math.Max(Math.Max(tierDiscount, promoDiscount), blackFriday);
    }

    /// <summary>
    /// Скидка по промокоду. STUDENT25 действует, только если все позиции —
    /// учебники. Для неизвестного кода бросает PricingException.
    /// </summary>
    public decimal ApplicablePromoDiscount(string? promoCode, IReadOnlyList<CartItem> items)
    {
        if (promoCode is null)
        {
            return 0m;
        }
        if (!PromoCodes.TryGetValue(promoCode, out var baseRate))
        {
            throw new PricingException($"Неизвестный промокод: {promoCode}");
        }
        if (promoCode == "STUDENT25")
        {
            var allTextbooks = items.All(i => i.Book.Category == StudentPromoCategory);
            return allTextbooks ? baseRate : 0m;
        }
        return baseRate;
    }

    /// <summary>
    /// Стоимость доставки. Бесплатно при наличии детских книг или при сумме
    /// заказа не ниже порога; иначе базовая ставка плюс надбавка за вес свыше
    /// 1 кг.
    /// </summary>
    public decimal CalculateDeliveryFee(IReadOnlyList<CartItem> items, decimal subtotalAfterDiscount)
    {
        if (HasChildrenBooks(items))
        {
            return 0m;
        }
        if (subtotalAfterDiscount >= FreeDeliveryThreshold)
        {
            return 0m;
        }

        var weight = items.Sum(i => i.Book.WeightGrams * i.Quantity);
        var fee = BaseDeliveryFee;
        if (weight > 1000)
        {
            var extraBlocks = (weight - 1000) / 100;
            fee += DeliveryPer100GramsOver1Kg * extraBlocks;
        }
        return fee;
    }

    /// <summary>НДС на книги от переданной суммы.</summary>
    public decimal CalculateVat(decimal amount)
    {
        return Math.Round(amount * VatRate, 2);
    }

    /// <summary>
    /// Проверить заказ перед расчётом: непустой, покупатель не заблокирован,
    /// количество в допустимых пределах, сумма в рамках лимита уровня.
    /// </summary>
    public void ValidateOrder(Order order)
    {
        if (order.IsEmpty)
        {
            throw new PricingException("Заказ не может быть пустым");
        }
        if (order.Customer.IsBlocked)
        {
            throw new PricingException("Покупатель заблокирован");
        }

        foreach (var item in order.Items)
        {
            if (item.Quantity <= 0)
            {
                throw new PricingException(
                    $"Количество должно быть положительным: {item.Book.Isbn}");
            }
            if (item.Quantity > MaxQuantityPerItem)
            {
                throw new PricingException(
                    $"Превышен лимит количества ({MaxQuantityPerItem}) для {item.Book.Isbn}");
            }
        }

        var limit = order.Customer.Tier == CustomerTier.GOLD
            ? OrderLimitGold
            : OrderLimitRegular;
        if (order.Subtotal > limit)
        {
            throw new PricingException(
                $"Сумма заказа {order.Subtotal} превышает лимит {limit}");
        }
    }

    /// <summary>Попадает ли момент в период распродажи «чёрная пятница».</summary>
    public static bool IsBlackFriday(DateTime moment)
    {
        var key = (moment.Month, moment.Day);
        return key.CompareTo(BlackFridayStart) >= 0
            && key.CompareTo(BlackFridayEnd) <= 0;
    }

    /// <summary>Сумма позиций, к которым применимы скидки (все, кроме коллекционных).</summary>
    private static decimal DiscountableSubtotal(IReadOnlyList<CartItem> items)
    {
        return items
            .Where(i => i.Book.Category != BookCategory.RARE)
            .Sum(i => i.LineTotal);
    }

    /// <summary>Сумма коллекционных книг, на которые скидки не распространяются.</summary>
    private static decimal NonDiscountableSubtotal(IReadOnlyList<CartItem> items)
    {
        return items
            .Where(i => i.Book.Category == BookCategory.RARE)
            .Sum(i => i.LineTotal);
    }

    /// <summary>Есть ли в заказе хотя бы одна детская книга.</summary>
    private static bool HasChildrenBooks(IReadOnlyList<CartItem> items)
    {
        return items.Any(i => i.Book.Category == BookCategory.CHILDREN);
    }
}
