using Bookstore.Interfaces;
using Bookstore.Models;

namespace Bookstore;

/// <summary>Рекомендованная книга с оценкой релевантности и пояснением.</summary>
public sealed record Recommendation(Book Book, double Score, string Reason);

/// <summary>Подбор рекомендаций книг для покупателя.</summary>
public class RecommendationService
{
    private readonly IBookRepository _books;
    private readonly IMLRecommendationProvider _ml;

    public RecommendationService(
        IBookRepository books,
        IMLRecommendationProvider ml)
    {
        _books = books;
        _ml = ml;
    }

    /// <summary>
    /// Подобрать до <paramref name="limit"/> рекомендаций. Заблокированным
    /// покупателям и при неположительном лимите возвращается пустой список.
    /// Если ML-сервис недоступен, используется простой подбор по популярным книгам.
    /// </summary>
    public IReadOnlyList<Recommendation> RecommendFor(Customer customer, int limit = 5)
    {
        if (customer.IsBlocked)
        {
            return Array.Empty<Recommendation>();
        }
        if (limit <= 0)
        {
            return Array.Empty<Recommendation>();
        }

        IReadOnlyList<string> isbns;
        try
        {
            isbns = _ml.RecommendIsbns(customer.CustomerId, limit * 2);
        }
        catch (InvalidOperationException)
        {
            return FallbackRecommendations(limit);
        }

        var candidates = new List<(Book Book, double Score)>();
        for (var i = 0; i < isbns.Count; i++)
        {
            Book book;
            try
            {
                book = _books.GetByIsbn(isbns[i]);
            }
            catch (BookNotFoundException)
            {
                continue;
            }
            var score = Math.Max(0.0, 1.0 - i * 0.1);
            candidates.Add((book, score));
        }

        return candidates
            .OrderByDescending(c => c.Score)
            .Take(limit)
            .Select(c => new Recommendation(c.Book, c.Score, "Рекомендовано на основе вашей истории"))
            .ToList();
    }

    /// <summary>Запасной подбор популярных книг художественной литературы.</summary>
    private IReadOnlyList<Recommendation> FallbackRecommendations(int limit)
    {
        var candidates = _books.Search("", limit * 3);
        var result = new List<Recommendation>();
        foreach (var book in candidates)
        {
            if (book.Category == BookCategory.FICTION && result.Count < limit)
            {
                result.Add(new Recommendation(book, 0.5, "Популярное в этой категории"));
            }
        }
        return result;
    }
}
