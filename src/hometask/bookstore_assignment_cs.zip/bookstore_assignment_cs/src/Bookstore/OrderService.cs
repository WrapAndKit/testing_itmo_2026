using Bookstore.Interfaces;
using Bookstore.Models;

namespace Bookstore;

/// <summary>Итог успешного оформления и оплаты заказа.</summary>
public sealed record CheckoutResult(
    Order Order,
    decimal Total,
    string PaymentTransactionId,
    IReadOnlyList<string> ReservationIds);

/// <summary>Оформление, оплата и отмена заказов.</summary>
public class OrderService
{
    private readonly IBookRepository _books;
    private readonly IInventoryService _inventory;
    private readonly IPaymentGateway _payment;
    private readonly INotificationService _notifications;
    private readonly IClock _clock;
    private readonly PricingService _pricing = new();

    public OrderService(
        IBookRepository books,
        IInventoryService inventory,
        IPaymentGateway payment,
        INotificationService notifications,
        IClock clock)
    {
        _books = books;
        _inventory = inventory;
        _payment = payment;
        _notifications = notifications;
        _clock = clock;
    }

    /// <summary>Создать новый пустой заказ для покупателя.</summary>
    public Order CreateOrder(Customer customer)
    {
        if (customer.IsBlocked)
        {
            throw new OrderException("Покупатель заблокирован");
        }
        return new Order(Guid.NewGuid().ToString(), customer);
    }

    /// <summary>
    /// Добавить книгу в заказ. Если книга уже есть, увеличить её количество.
    /// Резервирование на складе здесь не выполняется — только при оформлении.
    /// </summary>
    public void AddItem(Order order, string isbn, int quantity)
    {
        if (order.Status != OrderStatus.DRAFT)
        {
            throw new InvalidOrderStateException(
                $"Нельзя изменить заказ в статусе {order.Status}");
        }
        if (quantity <= 0)
        {
            throw new OrderException("Количество должно быть положительным");
        }

        var book = _books.GetByIsbn(isbn);

        foreach (var item in order.Items)
        {
            if (item.Book.Isbn == isbn)
            {
                item.Quantity += quantity;
                return;
            }
        }
        order.Items.Add(new CartItem(book, quantity));
    }

    /// <summary>Удалить книгу из заказа по ISBN.</summary>
    public void RemoveItem(Order order, string isbn)
    {
        if (order.Status != OrderStatus.DRAFT)
        {
            throw new InvalidOrderStateException(
                $"Нельзя изменить заказ в статусе {order.Status}");
        }
        order.Items = order.Items.Where(i => i.Book.Isbn != isbn).ToList();
    }

    /// <summary>Привязать промокод к заказу. Его корректность проверяется при расчёте.</summary>
    public void ApplyPromoCode(Order order, string code)
    {
        if (order.Status != OrderStatus.DRAFT)
        {
            throw new InvalidOrderStateException(
                "Промокод можно применить только к черновику");
        }
        order.PromoCode = code;
    }

    /// <summary>
    /// Оформить и оплатить заказ.
    ///
    /// Шаги: проверка остатков, резервирование, расчёт стоимости, списание
    /// средств, перевод заказа в статус PAID и отправка подтверждения. Если
    /// оплата не прошла, резервирования снимаются и заказ отменяется.
    /// </summary>
    public CheckoutResult Checkout(Order order, Address shippingAddress)
    {
        if (order.Status != OrderStatus.DRAFT)
        {
            throw new InvalidOrderStateException($"Заказ уже в статусе {order.Status}");
        }

        _pricing.ValidateOrder(order);
        order.ShippingAddress = shippingAddress;

        // Проверяем наличие до резервирования, чтобы быстро отказать.
        foreach (var item in order.Items)
        {
            var stock = _inventory.GetStock(item.Book.Isbn);
            if (stock < item.Quantity)
            {
                throw new InventoryException(
                    $"Недостаточно товара {item.Book.Isbn}: " +
                    $"требуется {item.Quantity}, доступно {stock}");
            }
        }

        // Резервируем все позиции. При сбое снимаем уже сделанные резервации.
        var reservations = new List<string>();
        try
        {
            foreach (var item in order.Items)
            {
                var reservationId = _inventory.Reserve(item.Book.Isbn, item.Quantity);
                reservations.Add(reservationId);
            }
        }
        catch (InventoryException)
        {
            foreach (var rid in reservations)
            {
                _inventory.Release(rid);
            }
            throw;
        }

        var breakdown = _pricing.CalculateOrderTotal(order, _clock.Now());
        var total = breakdown.Total;

        order.Status = OrderStatus.PENDING_PAYMENT;
        var idempotencyKey = $"order-{order.OrderId}";

        PaymentResult result;
        try
        {
            result = _payment.Charge(
                order.Customer.CustomerId,
                total,
                "RUB",
                idempotencyKey);

            if (result.Status != PaymentStatus.SUCCESS)
            {
                foreach (var rid in reservations)
                {
                    _inventory.Release(rid);
                }
                order.Status = OrderStatus.CANCELLED;
                throw new PaymentDeclinedException(
                    $"Платёж отклонён: {result.DeclineReason ?? result.Status.ToString()}");
            }
        }
        catch (PaymentException)
        {
            if (order.Status != OrderStatus.CANCELLED)
            {
                foreach (var rid in reservations)
                {
                    _inventory.Release(rid);
                }
                order.Status = OrderStatus.CANCELLED;
            }
            throw;
        }

        order.Status = OrderStatus.PAID;
        order.PaymentTransactionId = result.TransactionId;

        // Сбой отправки уведомления не отменяет уже оплаченный заказ.
        try
        {
            _notifications.SendOrderConfirmation(order.Customer, order);
        }
        catch
        {
            // не валим оплаченный заказ из-за ошибки уведомления
        }

        return new CheckoutResult(
            order,
            total,
            result.TransactionId ?? "",
            reservations);
    }

    /// <summary>Отменить заказ. Для оплаченного заказа выполняется возврат средств.</summary>
    public void Cancel(Order order)
    {
        if (order.Status is OrderStatus.CANCELLED
            or OrderStatus.DELIVERED
            or OrderStatus.REFUNDED)
        {
            throw new InvalidOrderStateException(
                $"Нельзя отменить заказ в статусе {order.Status}");
        }

        if (order.Status == OrderStatus.PAID && order.PaymentTransactionId is not null)
        {
            var breakdown = _pricing.CalculateOrderTotal(order, _clock.Now());
            _payment.Refund(order.PaymentTransactionId, breakdown.Total);
            order.Status = OrderStatus.REFUNDED;
        }
        else
        {
            order.Status = OrderStatus.CANCELLED;
        }
    }
}
