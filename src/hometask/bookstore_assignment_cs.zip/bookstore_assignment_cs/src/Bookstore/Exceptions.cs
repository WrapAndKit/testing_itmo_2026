namespace Bookstore;

/// <summary>Нарушение правил расчёта стоимости заказа.</summary>
public class PricingException : Exception
{
    public PricingException(string message) : base(message) { }
}

/// <summary>Базовая ошибка при работе с заказом.</summary>
public class OrderException : Exception
{
    public OrderException(string message) : base(message) { }
}

/// <summary>Операция недопустима в текущем статусе заказа.</summary>
public class InvalidOrderStateException : OrderException
{
    public InvalidOrderStateException(string message) : base(message) { }
}

/// <summary>Книга с указанным ISBN отсутствует в каталоге.</summary>
public class BookNotFoundException : Exception
{
    public BookNotFoundException(string message) : base(message) { }
}

/// <summary>Ошибка склада: нехватка товара или сбой сервиса остатков.</summary>
public class InventoryException : Exception
{
    public InventoryException(string message) : base(message) { }
}

/// <summary>Базовая ошибка платёжного шлюза.</summary>
public class PaymentException : Exception
{
    public PaymentException(string message) : base(message) { }
}

/// <summary>Платёж отклонён (карта, лимиты, антифрод).</summary>
public class PaymentDeclinedException : PaymentException
{
    public PaymentDeclinedException(string message) : base(message) { }
}

/// <summary>Курс валюты недоступен или валюта не поддерживается.</summary>
public class CurrencyException : Exception
{
    public CurrencyException(string message) : base(message) { }
}
