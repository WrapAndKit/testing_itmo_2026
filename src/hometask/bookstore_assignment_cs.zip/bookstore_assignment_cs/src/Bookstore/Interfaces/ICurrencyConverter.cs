namespace Bookstore.Interfaces;

/// <summary>Конвертация сумм между валютами по актуальному курсу.</summary>
public interface ICurrencyConverter
{
    /// <summary>
    /// Перевести сумму из одной валюты в другую. Без указания даты используется
    /// текущий курс. Бросает CurrencyException, если курс недоступен.
    /// </summary>
    decimal Convert(
        decimal amount,
        string fromCurrency,
        string toCurrency,
        DateTime? onDate = null);
}
