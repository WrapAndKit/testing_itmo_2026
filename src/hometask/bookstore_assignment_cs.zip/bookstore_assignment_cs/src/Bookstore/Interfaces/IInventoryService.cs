namespace Bookstore.Interfaces;

/// <summary>Управление остатками книг на складе.</summary>
public interface IInventoryService
{
    /// <summary>Текущий остаток книги на складе.</summary>
    int GetStock(string isbn);

    /// <summary>
    /// Зарезервировать количество книг и вернуть идентификатор резервации.
    /// Бросает InventoryException при нехватке товара.
    /// </summary>
    string Reserve(string isbn, int quantity);

    /// <summary>Снять резервацию (например, при отмене заказа).</summary>
    void Release(string reservationId);
}
