using Bookstore.Models;

namespace Bookstore.Interfaces;

/// <summary>Отправка уведомлений покупателю (email, SMS, push).</summary>
public interface INotificationService
{
    /// <summary>Отправить подтверждение оформленного заказа.</summary>
    void SendOrderConfirmation(Customer customer, Order order);

    /// <summary>Отправить уведомление об отправке заказа с трек-номером.</summary>
    void SendShippingNotification(Customer customer, Order order, string trackingNumber);
}
