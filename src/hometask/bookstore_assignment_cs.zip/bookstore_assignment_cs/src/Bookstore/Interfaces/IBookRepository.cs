using Bookstore.Models;

namespace Bookstore.Interfaces;

/// <summary>Источник данных о книгах (база каталога).</summary>
public interface IBookRepository
{
    /// <summary>Вернуть книгу по ISBN. Бросает BookNotFoundException, если книги нет.</summary>
    Book GetByIsbn(string isbn);

    /// <summary>Найти книги по подстроке в названии или авторе.</summary>
    IReadOnlyList<Book> Search(string query, int limit = 20);
}
