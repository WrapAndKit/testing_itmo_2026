namespace Bookstore.Interfaces;

/// <summary>
/// Источник текущего времени. Вынесён в зависимость, чтобы время можно было
/// подменять при расчёте сезонных правил (например, акций по датам).
/// </summary>
public interface IClock
{
    /// <summary>Текущий момент времени.</summary>
    DateTime Now();
}
