namespace Bookstore.Interfaces;

/// <summary>Внешний сервис рекомендаций, возвращающий ISBN подходящих книг.</summary>
public interface IMLRecommendationProvider
{
    /// <summary>
    /// Вернуть список ISBN рекомендованных книг.
    /// Бросает InvalidOperationException, если сервис недоступен.
    /// </summary>
    IReadOnlyList<string> RecommendIsbns(string customerId, int limit);
}
