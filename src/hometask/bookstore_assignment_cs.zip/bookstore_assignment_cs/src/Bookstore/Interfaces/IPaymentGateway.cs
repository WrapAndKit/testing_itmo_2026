namespace Bookstore.Interfaces;

/// <summary>Результат обращения к платёжному шлюзу.</summary>
public enum PaymentStatus
{
    SUCCESS,
    DECLINED,
    GATEWAY_ERROR,
    INSUFFICIENT_FUNDS,
}

/// <summary>Ответ платёжного шлюза на операцию списания или возврата.</summary>
public sealed record PaymentResult(
    PaymentStatus Status,
    string? TransactionId = null,
    string? DeclineReason = null);

/// <summary>Внешний платёжный провайдер.</summary>
public interface IPaymentGateway
{
    /// <summary>
    /// Списать средства. Повторный вызов с тем же ключом не дублирует платёж.
    /// </summary>
    PaymentResult Charge(
        string customerId,
        decimal amount,
        string currency,
        string idempotencyKey);

    /// <summary>Вернуть средства по ранее проведённой операции.</summary>
    PaymentResult Refund(string transactionId, decimal amount);
}
