namespace Bookstore.Models;

/// <summary>Адрес доставки заказа.</summary>
public sealed record Address(
    string Country,
    string City,
    string PostalCode,
    string Street);
