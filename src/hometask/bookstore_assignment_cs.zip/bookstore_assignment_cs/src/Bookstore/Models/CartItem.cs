namespace Bookstore.Models;

/// <summary>Позиция в заказе: книга и её количество.</summary>
public sealed class CartItem
{
    public Book Book { get; }
    public int Quantity { get; set; }

    public CartItem(Book book, int quantity)
    {
        Book = book;
        Quantity = quantity;
    }

    /// <summary>Стоимость позиции по базовой цене, без учёта скидок.</summary>
    public decimal LineTotal => Book.BasePrice * Quantity;
}
