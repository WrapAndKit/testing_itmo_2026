namespace Bookstore.Models;

/// <summary>Уровень покупателя. Определяет скидку и лимит заказа.</summary>
public enum CustomerTier
{
    BRONZE,
    SILVER,
    GOLD,
}

/// <summary>Покупатель магазина.</summary>
public sealed class Customer
{
    public string CustomerId { get; init; } = "";
    public string Name { get; init; } = "";
    public string Email { get; init; } = "";
    public CustomerTier Tier { get; set; } = CustomerTier.BRONZE;
    public int OrdersLastYear { get; set; }
    public string Country { get; set; } = "RU";
    public bool IsBlocked { get; set; }
}
