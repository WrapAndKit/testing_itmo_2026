namespace Bookstore.Models;

/// <summary>Категория книги. От неё зависят правила скидок и доставки.</summary>
public enum BookCategory
{
    FICTION,
    NON_FICTION,
    TEXTBOOK,
    CHILDREN,
    RARE,
}

/// <summary>Книга в каталоге магазина. Неизменяемый объект.</summary>
public sealed record Book(
    string Isbn,
    string Title,
    string Author,
    BookCategory Category,
    decimal BasePrice,
    int WeightGrams,
    int PublicationYear);
