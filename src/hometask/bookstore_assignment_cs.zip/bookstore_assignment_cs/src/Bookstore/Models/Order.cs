namespace Bookstore.Models;

/// <summary>Текущее состояние заказа в его жизненном цикле.</summary>
public enum OrderStatus
{
    DRAFT,
    PENDING_PAYMENT,
    PAID,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    REFUNDED,
}

/// <summary>Заказ покупателя со списком позиций и текущим статусом.</summary>
public sealed class Order
{
    public string OrderId { get; }
    public Customer Customer { get; }
    public List<CartItem> Items { get; set; } = new();
    public OrderStatus Status { get; set; } = OrderStatus.DRAFT;
    public string? PromoCode { get; set; }
    public Address? ShippingAddress { get; set; }
    public DateTime CreatedAt { get; } = DateTime.UtcNow;
    public string? PaymentTransactionId { get; set; }

    public Order(string orderId, Customer customer)
    {
        OrderId = orderId;
        Customer = customer;
    }

    /// <summary>Сумма всех позиций по базовым ценам, без скидок и доставки.</summary>
    public decimal Subtotal => Items.Sum(i => i.LineTotal);

    /// <summary>Суммарный вес всех книг заказа в граммах.</summary>
    public int TotalWeightGrams => Items.Sum(i => i.Book.WeightGrams * i.Quantity);

    /// <summary>True, если в заказе нет ни одной позиции.</summary>
    public bool IsEmpty => Items.Count == 0;
}
