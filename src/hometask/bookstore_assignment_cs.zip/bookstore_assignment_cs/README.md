# Интернет-магазин книг (C#)

Серверная часть интернет-магазина книг на ASP.NET Core: оформление и оплата заказов, расчёт стоимости со скидками, доставкой и налогом, подбор рекомендаций.

Техническое задание — в [`docs/REQUIREMENTS.md`](docs/REQUIREMENTS.md).
Задание для тестирования — в [`docs/ASSIGNMENT.md`](docs/ASSIGNMENT.md).

## Установка

Требуется .NET 8 SDK.

```bash
dotnet restore
```

## Запуск

По умолчанию `dotnet run` запускает **демо-режим**: подключены реализации зависимостей в памяти, заведён тестовый покупатель `demo`, корень `/` перенаправляет на Swagger UI.

```bash
dotnet run --project src/Bookstore.Api
```

Откройте http://localhost:5000/docs — там можно потыкать API.

**Режим задания** (зависимости не подключены — то, против чего студенты пишут тесты с подменой двойников):

```bash
dotnet run --project src/Bookstore.Api --launch-profile Assignment
```

Профили запуска описаны в `src/Bookstore.Api/Properties/launchSettings.json`.
