export const ML_RECOMMENDATION_PROVIDER = Symbol('MLRecommendationProvider');

/** Внешний сервис рекомендаций, возвращающий ISBN подходящих книг. */
export interface MLRecommendationProvider {
  /**
   * Вернуть список ISBN рекомендованных книг.
   * Бросает RuntimeError, если сервис недоступен.
   */
  recommendIsbns(customerId: string, limit: number): string[];
}
