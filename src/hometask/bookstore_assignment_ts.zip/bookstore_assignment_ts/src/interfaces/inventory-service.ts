export const INVENTORY_SERVICE = Symbol('InventoryService');

/** Управление остатками книг на складе. */
export interface InventoryService {
  /** Текущий остаток книги на складе. */
  getStock(isbn: string): number;

  /**
   * Зарезервировать количество книг и вернуть идентификатор резервации.
   * Бросает InventoryError при нехватке товара.
   */
  reserve(isbn: string, quantity: number): string;

  /** Снять резервацию (например, при отмене заказа). */
  release(reservationId: string): void;
}
