import { Customer } from '../models/customer';
import { Order } from '../models/order';

export const NOTIFICATION_SERVICE = Symbol('NotificationService');

/** Отправка уведомлений покупателю (email, SMS, push). */
export interface NotificationService {
  /** Отправить подтверждение оформленного заказа. */
  sendOrderConfirmation(customer: Customer, order: Order): void;

  /** Отправить уведомление об отправке заказа с трек-номером. */
  sendShippingNotification(
    customer: Customer,
    order: Order,
    trackingNumber: string,
  ): void;
}
