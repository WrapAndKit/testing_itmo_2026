export const CURRENCY_CONVERTER = Symbol('CurrencyConverter');

/** Конвертация сумм между валютами по актуальному курсу. */
export interface CurrencyConverter {
  /**
   * Перевести сумму из одной валюты в другую. Без указания даты используется
   * текущий курс. Бросает CurrencyError, если курс недоступен.
   */
  convert(
    amount: number,
    fromCurrency: string,
    toCurrency: string,
    onDate?: Date,
  ): number;
}
