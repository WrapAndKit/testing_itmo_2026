export const PAYMENT_GATEWAY = Symbol('PaymentGateway');

export enum PaymentStatus {
  SUCCESS = 'SUCCESS',
  DECLINED = 'DECLINED',
  GATEWAY_ERROR = 'GATEWAY_ERROR',
  INSUFFICIENT_FUNDS = 'INSUFFICIENT_FUNDS',
}

/** Ответ платёжного шлюза на операцию списания или возврата. */
export class PaymentResult {
  constructor(
    public readonly status: PaymentStatus,
    public readonly transactionId: string | null = null,
    public readonly declineReason: string | null = null,
  ) {}
}

/** Внешний платёжный провайдер. */
export interface PaymentGateway {
  /** Списать средства. Повторный вызов с тем же ключом не дублирует платёж. */
  charge(
    customerId: string,
    amount: number,
    currency: string,
    idempotencyKey: string,
  ): PaymentResult;

  /** Вернуть средства по ранее проведённой операции. */
  refund(transactionId: string, amount: number): PaymentResult;
}
