import { Book } from '../models/book';

export const BOOK_REPOSITORY = Symbol('BookRepository');

/** Источник данных о книгах (база каталога). */
export interface BookRepository {
  /** Вернуть книгу по ISBN. Бросает BookNotFoundError, если книги нет. */
  getByIsbn(isbn: string): Book;

  /** Найти книги по подстроке в названии или авторе. */
  search(query: string, limit?: number): Book[];
}
