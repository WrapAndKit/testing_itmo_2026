import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

import { BookstoreModule } from './api';

async function bootstrap() {
  const app = await NestFactory.create(BookstoreModule);

  const config = new DocumentBuilder()
    .setTitle('Bookstore API')
    .setDescription('Интернет-магазин книг')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('docs', app, document);

  await app.listen(3000);
  console.log('Bookstore API: http://localhost:3000');
  console.log('Swagger UI:    http://localhost:3000/docs');
}

bootstrap();
