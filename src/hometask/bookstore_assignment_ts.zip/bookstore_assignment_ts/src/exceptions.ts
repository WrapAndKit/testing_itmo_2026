/** Нарушение правил расчёта стоимости заказа. */
export class PricingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PricingError';
  }
}

/** Базовая ошибка при работе с заказом. */
export class OrderError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'OrderError';
  }
}

/** Операция недопустима в текущем статусе заказа. */
export class InvalidOrderStateError extends OrderError {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidOrderStateError';
  }
}

/** Книга с указанным ISBN отсутствует в каталоге. */
export class BookNotFoundError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'BookNotFoundError';
  }
}

/** Ошибка склада: нехватка товара или сбой сервиса остатков. */
export class InventoryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InventoryError';
  }
}

/** Базовая ошибка платёжного шлюза. */
export class PaymentError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PaymentError';
  }
}

/** Платёж отклонён (карта, лимиты, антифрод). */
export class PaymentDeclinedError extends PaymentError {
  constructor(message: string) {
    super(message);
    this.name = 'PaymentDeclinedError';
  }
}

/** Курс валюты недоступен или валюта не поддерживается. */
export class CurrencyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CurrencyError';
  }
}
