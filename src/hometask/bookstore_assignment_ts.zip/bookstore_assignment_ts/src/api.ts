import {
  BadRequestException,
  Body,
  ConflictException,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  HttpCode,
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  Module,
  NotFoundException,
  Param,
  Post,
  UnprocessableEntityException,
  ValidationPipe,
} from '@nestjs/common';
import { APP_PIPE } from '@nestjs/core';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsString,
  Max,
  Min,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

import {
  BookNotFoundError,
  InvalidOrderStateError,
  InventoryError,
  OrderError,
  PaymentDeclinedError,
  PaymentError,
  PricingError,
} from './exceptions';
import {
  BOOK_REPOSITORY,
  CLOCK,
  INVENTORY_SERVICE,
  NOTIFICATION_SERVICE,
  PAYMENT_GATEWAY,
} from './interfaces';
import { BookRepository } from './interfaces/book-repository';
import { Clock } from './interfaces/clock';
import { InventoryService } from './interfaces/inventory-service';
import { NotificationService } from './interfaces/notification-service';
import { PaymentGateway } from './interfaces/payment-gateway';
import { Address } from './models/address';
import { Customer } from './models/customer';
import { Order } from './models/order';
import { CheckoutResult, OrderService } from './order-service';

// Хранилища заказов и покупателей. В реальной системе — база данных.
export const ORDERS_STORAGE = Symbol('OrdersStorage');
export const CUSTOMERS_STORAGE = Symbol('CustomersStorage');

// --- Заглушки реализаций зависимостей ---
// Бросают ошибку при первом вызове любого метода. Подменяются при сборке
// приложения (для боевого запуска) или в тестах (для подмены двойниками).

class NotConfigured {
  constructor(public readonly name: string) {}
  fail(): never {
    throw new Error(`Реализация ${this.name} не подключена`);
  }
}

class StubBookRepository extends NotConfigured implements BookRepository {
  constructor() { super('BookRepository'); }
  getByIsbn(): never { this.fail(); }
  search(): never { this.fail(); }
}
class StubInventoryService extends NotConfigured implements InventoryService {
  constructor() { super('InventoryService'); }
  getStock(): never { this.fail(); }
  reserve(): never { this.fail(); }
  release(): never { this.fail(); }
}
class StubPaymentGateway extends NotConfigured implements PaymentGateway {
  constructor() { super('PaymentGateway'); }
  charge(): never { this.fail(); }
  refund(): never { this.fail(); }
}
class StubNotificationService
  extends NotConfigured
  implements NotificationService
{
  constructor() { super('NotificationService'); }
  sendOrderConfirmation(): never { this.fail(); }
  sendShippingNotification(): never { this.fail(); }
}
class StubClock extends NotConfigured implements Clock {
  constructor() { super('Clock'); }
  now(): never { this.fail(); }
}

// --- DTO для входящих запросов ---

export class CreateOrderRequest {
  @ApiProperty({ example: 'demo' })
  @IsString()
  @MinLength(1)
  customer_id!: string;
}

export class AddItemRequest {
  @ApiProperty({ example: '978-5-0010-0001-1' })
  @IsString()
  @MinLength(10)
  isbn!: string;

  @ApiProperty({ example: 2, minimum: 1, maximum: 100 })
  @IsInt()
  @Min(1)
  @Max(100)
  quantity!: number;
}

export class ApplyPromoRequest {
  @ApiProperty({ example: 'WELCOME15' })
  @IsString()
  @MinLength(2)
  code!: string;
}

export class AddressDto {
  @ApiProperty({ example: 'RU' })
  @IsString()
  @MinLength(2)
  country!: string;

  @ApiProperty({ example: 'Москва' })
  @IsString()
  city!: string;

  @ApiProperty({ example: '101000' })
  @IsString()
  postal_code!: string;

  @ApiProperty({ example: 'Тверская, 1' })
  @IsString()
  street!: string;
}

export class CheckoutRequest {
  @ApiProperty({ type: AddressDto })
  @ValidateNested()
  @Type(() => AddressDto)
  shipping_address!: AddressDto;
}

// --- Представления для исходящих ответов ---

interface OrderResponse {
  order_id: string;
  status: string;
  customer_id: string;
  items_count: number;
  subtotal: number;
  promo_code: string | null;
}

function toResponse(order: Order): OrderResponse {
  return {
    order_id: order.orderId,
    status: order.status,
    customer_id: order.customer.customerId,
    items_count: order.items.length,
    subtotal: order.subtotal,
    promo_code: order.promoCode,
  };
}

interface CheckoutResponseBody {
  order_id: string;
  status: string;
  total: number;
  transaction_id: string;
}

// --- Контроллер ---

/** HTTP-эндпоинты для управления заказами. */
@Controller()
export class BookstoreController {
  constructor(
    private readonly orderService: OrderService,
    @Inject(ORDERS_STORAGE)
    private readonly orders: Map<string, Order>,
    @Inject(CUSTOMERS_STORAGE)
    private readonly customers: Map<string, Customer>,
  ) {}

  @Post('orders')
  @HttpCode(HttpStatus.CREATED)
  createOrder(@Body() body: CreateOrderRequest): OrderResponse {
    const customer = this.customers.get(body.customer_id);
    if (!customer) {
      throw new NotFoundException(`Покупатель ${body.customer_id} не найден`);
    }
    try {
      const order = this.orderService.createOrder(customer);
      this.orders.set(order.orderId, order);
      return toResponse(order);
    } catch (e) {
      if (e instanceof OrderError) {
        throw new ForbiddenException(e.message);
      }
      throw e;
    }
  }

  @Get('orders/:orderId')
  getOrder(@Param('orderId') orderId: string): OrderResponse {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new NotFoundException(`Заказ ${orderId} не найден`);
    }
    return toResponse(order);
  }

  @Post('orders/:orderId/items')
  @HttpCode(HttpStatus.OK)
  addItem(
    @Param('orderId') orderId: string,
    @Body() body: AddItemRequest,
  ): OrderResponse {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new NotFoundException(`Заказ ${orderId} не найден`);
    }
    try {
      this.orderService.addItem(order, body.isbn, body.quantity);
    } catch (e) {
      if (e instanceof BookNotFoundError) {
        throw new NotFoundException(e.message);
      }
      if (e instanceof InvalidOrderStateError) {
        throw new ConflictException(e.message);
      }
      if (e instanceof OrderError) {
        throw new BadRequestException(e.message);
      }
      throw e;
    }
    return toResponse(order);
  }

  @Delete('orders/:orderId/items/:isbn')
  removeItem(
    @Param('orderId') orderId: string,
    @Param('isbn') isbn: string,
  ): OrderResponse {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new NotFoundException(`Заказ ${orderId} не найден`);
    }
    try {
      this.orderService.removeItem(order, isbn);
    } catch (e) {
      if (e instanceof InvalidOrderStateError) {
        throw new ConflictException(e.message);
      }
      throw e;
    }
    return toResponse(order);
  }

  @Post('orders/:orderId/promo')
  @HttpCode(HttpStatus.OK)
  applyPromo(
    @Param('orderId') orderId: string,
    @Body() body: ApplyPromoRequest,
  ): OrderResponse {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new NotFoundException(`Заказ ${orderId} не найден`);
    }
    try {
      this.orderService.applyPromoCode(order, body.code);
    } catch (e) {
      if (e instanceof InvalidOrderStateError) {
        throw new ConflictException(e.message);
      }
      throw e;
    }
    return toResponse(order);
  }

  @Post('orders/:orderId/checkout')
  @HttpCode(HttpStatus.OK)
  checkout(
    @Param('orderId') orderId: string,
    @Body() body: CheckoutRequest,
  ): CheckoutResponseBody {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new NotFoundException(`Заказ ${orderId} не найден`);
    }
    const address = new Address(
      body.shipping_address.country,
      body.shipping_address.city,
      body.shipping_address.postal_code,
      body.shipping_address.street,
    );
    let result: CheckoutResult;
    try {
      result = this.orderService.checkout(order, address);
    } catch (e) {
      if (e instanceof InvalidOrderStateError) {
        throw new ConflictException(e.message);
      }
      if (e instanceof PricingError) {
        throw new UnprocessableEntityException(e.message);
      }
      if (e instanceof InventoryError) {
        throw new ConflictException(e.message);
      }
      if (e instanceof PaymentDeclinedError) {
        throw new HttpException(e.message, HttpStatus.PAYMENT_REQUIRED);
      }
      if (e instanceof PaymentError) {
        throw new HttpException(e.message, HttpStatus.BAD_GATEWAY);
      }
      throw e;
    }
    return {
      order_id: result.order.orderId,
      status: result.order.status,
      total: result.total,
      transaction_id: result.paymentTransactionId,
    };
  }

  @Post('orders/:orderId/cancel')
  @HttpCode(HttpStatus.OK)
  cancel(@Param('orderId') orderId: string): OrderResponse {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new NotFoundException(`Заказ ${orderId} не найден`);
    }
    try {
      this.orderService.cancel(order);
    } catch (e) {
      if (e instanceof InvalidOrderStateError) {
        throw new ConflictException(e.message);
      }
      throw e;
    }
    return toResponse(order);
  }
}

// --- Модуль ---

/**
 * Корневой модуль приложения. Внешние зависимости по умолчанию подключены
 * заглушками, которые бросают ошибку при первом вызове. Подменяются при
 * сборке приложения через override в Test.createTestingModule() (в тестах)
 * или через отдельный модуль с реализациями.
 */
@Module({
  controllers: [BookstoreController],
  providers: [
    OrderService,
    { provide: BOOK_REPOSITORY, useClass: StubBookRepository },
    { provide: INVENTORY_SERVICE, useClass: StubInventoryService },
    { provide: PAYMENT_GATEWAY, useClass: StubPaymentGateway },
    { provide: NOTIFICATION_SERVICE, useClass: StubNotificationService },
    { provide: CLOCK, useClass: StubClock },
    { provide: ORDERS_STORAGE, useValue: new Map<string, Order>() },
    { provide: CUSTOMERS_STORAGE, useValue: new Map<string, Customer>() },
    {
      provide: APP_PIPE,
      useFactory: () =>
        new ValidationPipe({
          transform: true,
          whitelist: true,
          errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        }),
    },
  ],
})
export class BookstoreModule {}
