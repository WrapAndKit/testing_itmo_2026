import { Inject, Injectable } from '@nestjs/common';

import { BookNotFoundError } from './exceptions';
import {
  BOOK_REPOSITORY,
  ML_RECOMMENDATION_PROVIDER,
} from './interfaces';
import { BookRepository } from './interfaces/book-repository';
import { MLRecommendationProvider } from './interfaces/ml-recommendation-provider';
import { Book, BookCategory } from './models/book';
import { Customer } from './models/customer';

/** Рекомендованная книга с оценкой релевантности и пояснением. */
export class Recommendation {
  constructor(
    public readonly book: Book,
    public readonly score: number,
    public readonly reason: string,
  ) {}
}

/** Подбор рекомендаций книг для покупателя. */
@Injectable()
export class RecommendationService {
  constructor(
    @Inject(BOOK_REPOSITORY) private readonly books: BookRepository,
    @Inject(ML_RECOMMENDATION_PROVIDER)
    private readonly ml: MLRecommendationProvider,
  ) {}

  /**
   * Подобрать до `limit` рекомендаций. Заблокированным покупателям и при
   * неположительном лимите возвращается пустой список. Если ML-сервис
   * недоступен, используется простой подбор по популярным книгам.
   */
  recommendFor(customer: Customer, limit = 5): Recommendation[] {
    if (customer.isBlocked) {
      return [];
    }
    if (limit <= 0) {
      return [];
    }

    let isbns: string[];
    try {
      isbns = this.ml.recommendIsbns(customer.customerId, limit * 2);
    } catch {
      return this.fallbackRecommendations(limit);
    }

    const candidates: Array<{ book: Book; score: number }> = [];
    isbns.forEach((isbn, index) => {
      let book: Book;
      try {
        book = this.books.getByIsbn(isbn);
      } catch (e) {
        if (e instanceof BookNotFoundError) {
          return;
        }
        throw e;
      }
      const score = Math.max(0.0, 1.0 - index * 0.1);
      candidates.push({ book, score });
    });

    candidates.sort((a, b) => b.score - a.score);
    return candidates
      .slice(0, limit)
      .map(
        ({ book, score }) =>
          new Recommendation(book, score, 'Рекомендовано на основе вашей истории'),
      );
  }

  /** Запасной подбор популярных книг художественной литературы. */
  private fallbackRecommendations(limit: number): Recommendation[] {
    const candidates = this.books.search('', limit * 3);
    const result: Recommendation[] = [];
    for (const book of candidates) {
      if (book.category === BookCategory.FICTION && result.length < limit) {
        result.push(new Recommendation(book, 0.5, 'Популярное в этой категории'));
      }
    }
    return result;
  }
}
