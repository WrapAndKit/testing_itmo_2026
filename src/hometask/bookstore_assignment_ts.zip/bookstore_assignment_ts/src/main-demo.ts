import 'reflect-metadata';
import { Injectable, Module } from '@nestjs/common';
import { APP_PIPE, NestFactory } from '@nestjs/core';
import { HttpStatus, ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { randomUUID } from 'crypto';
import { Request, Response } from 'express';

import {
  BookstoreController,
  CUSTOMERS_STORAGE,
  ORDERS_STORAGE,
} from './api';
import { BookNotFoundError, InventoryError } from './exceptions';
import {
  BOOK_REPOSITORY,
  CLOCK,
  INVENTORY_SERVICE,
  NOTIFICATION_SERVICE,
  PAYMENT_GATEWAY,
} from './interfaces';
import { BookRepository } from './interfaces/book-repository';
import { Clock } from './interfaces/clock';
import { InventoryService } from './interfaces/inventory-service';
import { NotificationService } from './interfaces/notification-service';
import {
  PaymentGateway,
  PaymentResult,
  PaymentStatus,
} from './interfaces/payment-gateway';
import { Book, BookCategory } from './models/book';
import { Customer, CustomerTier } from './models/customer';
import { Order } from './models/order';
import { OrderService } from './order-service';

// --- Каталог книг в памяти (по одной книге каждой категории) ---
const CATALOG: Record<string, Book> = {
  '978-5-0010-0001-1': new Book(
    '978-5-0010-0001-1', 'Чистый код', 'Роберт Мартин',
    BookCategory.NON_FICTION, 1500, 600, 2019,
  ),
  '978-5-0010-0002-2': new Book(
    '978-5-0010-0002-2', 'Высшая математика', 'А. Иванов',
    BookCategory.TEXTBOOK, 900, 800, 2021,
  ),
  '978-5-0010-0003-3': new Book(
    '978-5-0010-0003-3', 'Сказки на ночь', 'М. Петрова',
    BookCategory.CHILDREN, 500, 300, 2020,
  ),
  '978-5-0010-0004-4': new Book(
    '978-5-0010-0004-4', 'Первое издание', 'Редкий Автор',
    BookCategory.RARE, 12000, 1200, 1965,
  ),
  '978-5-0010-0005-5': new Book(
    '978-5-0010-0005-5', 'Война и мир', 'Л. Толстой',
    BookCategory.FICTION, 800, 1400, 2018,
  ),
};

/** Каталог книг в памяти. */
@Injectable()
class InMemoryBookRepository implements BookRepository {
  getByIsbn(isbn: string): Book {
    const book = CATALOG[isbn];
    if (!book) {
      throw new BookNotFoundError(`Книга ${isbn} не найдена`);
    }
    return book;
  }

  search(query: string, limit = 20): Book[] {
    const q = query.toLowerCase();
    return Object.values(CATALOG)
      .filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q),
      )
      .slice(0, limit);
  }
}

/** Склад в памяти. У каждой книги по 100 экземпляров. */
@Injectable()
class InMemoryInventory implements InventoryService {
  private stock: Map<string, number> = new Map(
    Object.keys(CATALOG).map((isbn) => [isbn, 100]),
  );
  private reservations = new Map<string, [string, number]>();
  private counter = 1;

  getStock(isbn: string): number {
    return this.stock.get(isbn) ?? 0;
  }

  reserve(isbn: string, quantity: number): string {
    const available = this.stock.get(isbn) ?? 0;
    if (available < quantity) {
      throw new InventoryError(`Недостаточно товара ${isbn}`);
    }
    this.stock.set(isbn, available - quantity);
    const reservationId = `RES-${this.counter++}`;
    this.reservations.set(reservationId, [isbn, quantity]);
    return reservationId;
  }

  release(reservationId: string): void {
    const entry = this.reservations.get(reservationId);
    if (entry) {
      const [isbn, quantity] = entry;
      this.stock.set(isbn, (this.stock.get(isbn) ?? 0) + quantity);
      this.reservations.delete(reservationId);
    }
  }
}

/** Платёжный шлюз, который всегда подтверждает оплату. */
@Injectable()
class FakePaymentGateway implements PaymentGateway {
  private counter = 1;

  charge(): PaymentResult {
    return new PaymentResult(PaymentStatus.SUCCESS, `TX-${this.counter++}`);
  }

  refund(): PaymentResult {
    return new PaymentResult(PaymentStatus.SUCCESS, `RF-${this.counter++}`);
  }
}

/** Уведомления, которые печатаются в консоль. */
@Injectable()
class ConsoleNotifications implements NotificationService {
  sendOrderConfirmation(customer: Customer, order: Order): void {
    console.log(
      `[notify] Заказ ${order.orderId} подтверждён для ${customer.email}`,
    );
  }

  sendShippingNotification(
    customer: Customer,
    order: Order,
    trackingNumber: string,
  ): void {
    console.log(
      `[notify] Заказ ${order.orderId} отправлен, трек ${trackingNumber}`,
    );
  }
}

/** Системные часы. */
@Injectable()
class SystemClock implements Clock {
  now(): Date {
    return new Date();
  }
}

// --- Хранилища и начальные данные ---
const ordersDb = new Map<string, Order>();
const customersDb = new Map<string, Customer>([
  [
    'demo',
    new Customer(
      'demo',
      'Демо Покупатель',
      'demo@example.com',
      CustomerTier.SILVER,
    ),
  ],
]);

/** Демонстрационный модуль с реализациями зависимостей в памяти. */
@Module({
  controllers: [BookstoreController],
  providers: [
    OrderService,
    { provide: BOOK_REPOSITORY, useClass: InMemoryBookRepository },
    { provide: INVENTORY_SERVICE, useClass: InMemoryInventory },
    { provide: PAYMENT_GATEWAY, useClass: FakePaymentGateway },
    { provide: NOTIFICATION_SERVICE, useClass: ConsoleNotifications },
    { provide: CLOCK, useClass: SystemClock },
    { provide: ORDERS_STORAGE, useValue: ordersDb },
    { provide: CUSTOMERS_STORAGE, useValue: customersDb },
    {
      provide: APP_PIPE,
      useFactory: () =>
        new ValidationPipe({
          transform: true,
          whitelist: true,
          errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        }),
    },
  ],
})
class DemoModule {}

async function bootstrap() {
  const app = await NestFactory.create(DemoModule);

  const config = new DocumentBuilder()
    .setTitle('Bookstore API (demo)')
    .setDescription('Интернет-магазин книг — демо-режим')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('docs', app, document);

  // Корневой адрес перенаправляет на Swagger UI.
  const server = app.getHttpAdapter().getInstance();
  server.get('/', (_req: Request, res: Response) => res.redirect('/docs'));

  await app.listen(3000);
  console.log('Демо-режим. Swagger UI: http://localhost:3000/docs');
  console.log('Покупатель: demo. Примеры ISBN:', Object.keys(CATALOG).join(', '));
}

bootstrap();
