import { randomUUID } from 'crypto';
import { Inject, Injectable } from '@nestjs/common';

import {
  InvalidOrderStateError,
  InventoryError,
  OrderError,
  PaymentDeclinedError,
  PaymentError,
} from './exceptions';
import {
  BOOK_REPOSITORY,
  CLOCK,
  INVENTORY_SERVICE,
  NOTIFICATION_SERVICE,
  PAYMENT_GATEWAY,
} from './interfaces';
import { BookRepository } from './interfaces/book-repository';
import { Clock } from './interfaces/clock';
import { InventoryService } from './interfaces/inventory-service';
import { NotificationService } from './interfaces/notification-service';
import {
  PaymentGateway,
  PaymentStatus,
} from './interfaces/payment-gateway';
import { Address } from './models/address';
import { CartItem } from './models/cart-item';
import { Customer } from './models/customer';
import { Order, OrderStatus } from './models/order';
import { PricingService } from './pricing';

/** Итог успешного оформления и оплаты заказа. */
export class CheckoutResult {
  constructor(
    public readonly order: Order,
    public readonly total: number,
    public readonly paymentTransactionId: string,
    public readonly reservationIds: string[],
  ) {}
}

/** Оформление, оплата и отмена заказов. */
@Injectable()
export class OrderService {
  private readonly pricing = new PricingService();

  constructor(
    @Inject(BOOK_REPOSITORY) private readonly books: BookRepository,
    @Inject(INVENTORY_SERVICE) private readonly inventory: InventoryService,
    @Inject(PAYMENT_GATEWAY) private readonly payment: PaymentGateway,
    @Inject(NOTIFICATION_SERVICE) private readonly notifications: NotificationService,
    @Inject(CLOCK) private readonly clock: Clock,
  ) {}

  /** Создать новый пустой заказ для покупателя. */
  createOrder(customer: Customer): Order {
    if (customer.isBlocked) {
      throw new OrderError('Покупатель заблокирован');
    }
    return new Order(randomUUID(), customer);
  }

  /**
   * Добавить книгу в заказ. Если книга уже есть, увеличить её количество.
   * Резервирование на складе здесь не выполняется — только при оформлении.
   */
  addItem(order: Order, isbn: string, quantity: number): void {
    if (order.status !== OrderStatus.DRAFT) {
      throw new InvalidOrderStateError(
        `Нельзя изменить заказ в статусе ${order.status}`,
      );
    }
    if (quantity <= 0) {
      throw new OrderError('Количество должно быть положительным');
    }

    const book = this.books.getByIsbn(isbn);

    for (const item of order.items) {
      if (item.book.isbn === isbn) {
        item.quantity += quantity;
        return;
      }
    }
    order.items.push(new CartItem(book, quantity));
  }

  /** Удалить книгу из заказа по ISBN. */
  removeItem(order: Order, isbn: string): void {
    if (order.status !== OrderStatus.DRAFT) {
      throw new InvalidOrderStateError(
        `Нельзя изменить заказ в статусе ${order.status}`,
      );
    }
    order.items = order.items.filter((item) => item.book.isbn !== isbn);
  }

  /** Привязать промокод к заказу. Его корректность проверяется при расчёте. */
  applyPromoCode(order: Order, code: string): void {
    if (order.status !== OrderStatus.DRAFT) {
      throw new InvalidOrderStateError(
        'Промокод можно применить только к черновику',
      );
    }
    order.promoCode = code;
  }

  /**
   * Оформить и оплатить заказ.
   *
   * Шаги: проверка остатков, резервирование, расчёт стоимости, списание
   * средств, перевод заказа в статус PAID и отправка подтверждения. Если
   * оплата не прошла, резервирования снимаются и заказ отменяется.
   */
  checkout(order: Order, shippingAddress: Address): CheckoutResult {
    if (order.status !== OrderStatus.DRAFT) {
      throw new InvalidOrderStateError(`Заказ уже в статусе ${order.status}`);
    }

    this.pricing.validateOrder(order);
    order.shippingAddress = shippingAddress;

    // Проверяем наличие до резервирования, чтобы быстро отказать.
    for (const item of order.items) {
      const stock = this.inventory.getStock(item.book.isbn);
      if (stock < item.quantity) {
        throw new InventoryError(
          `Недостаточно товара ${item.book.isbn}: требуется ${item.quantity}, доступно ${stock}`,
        );
      }
    }

    // Резервируем все позиции. При сбое снимаем уже сделанные резервации.
    const reservations: string[] = [];
    try {
      for (const item of order.items) {
        const reservationId = this.inventory.reserve(item.book.isbn, item.quantity);
        reservations.push(reservationId);
      }
    } catch (e) {
      for (const rid of reservations) {
        this.inventory.release(rid);
      }
      throw e;
    }

    const breakdown = this.pricing.calculateOrderTotal(order, this.clock.now());
    const total = breakdown.total;

    order.status = OrderStatus.PENDING_PAYMENT;
    const idempotencyKey = `order-${order.orderId}`;

    let paymentTransactionId: string | null = null;
    try {
      const result = this.payment.charge(
        order.customer.customerId,
        total,
        'RUB',
        idempotencyKey,
      );
      if (result.status !== PaymentStatus.SUCCESS) {
        for (const rid of reservations) {
          this.inventory.release(rid);
        }
        order.status = OrderStatus.CANCELLED;
        throw new PaymentDeclinedError(
          `Платёж отклонён: ${result.declineReason ?? result.status}`,
        );
      }
      paymentTransactionId = result.transactionId;
    } catch (e) {
      if (e instanceof PaymentError) {
        if (order.status !== OrderStatus.CANCELLED) {
          for (const rid of reservations) {
            this.inventory.release(rid);
          }
          order.status = OrderStatus.CANCELLED;
        }
        throw e;
      }
      throw e;
    }

    order.status = OrderStatus.PAID;
    order.paymentTransactionId = paymentTransactionId;

    // Сбой отправки уведомления не отменяет уже оплаченный заказ.
    try {
      this.notifications.sendOrderConfirmation(order.customer, order);
    } catch {
      // не валим оплаченный заказ из-за ошибки уведомления
    }

    return new CheckoutResult(
      order,
      total,
      paymentTransactionId ?? '',
      reservations,
    );
  }

  /** Отменить заказ. Для оплаченного заказа выполняется возврат средств. */
  cancel(order: Order): void {
    if (
      order.status === OrderStatus.CANCELLED ||
      order.status === OrderStatus.DELIVERED ||
      order.status === OrderStatus.REFUNDED
    ) {
      throw new InvalidOrderStateError(
        `Нельзя отменить заказ в статусе ${order.status}`,
      );
    }

    if (order.status === OrderStatus.PAID && order.paymentTransactionId) {
      const breakdown = this.pricing.calculateOrderTotal(order, this.clock.now());
      this.payment.refund(order.paymentTransactionId, breakdown.total);
      order.status = OrderStatus.REFUNDED;
    } else {
      order.status = OrderStatus.CANCELLED;
    }
  }
}
