import { Injectable } from '@nestjs/common';

import { PricingError } from './exceptions';
import { BookCategory } from './models/book';
import { CartItem } from './models/cart-item';
import { CustomerTier } from './models/customer';
import { Order } from './models/order';

// Скидка по уровню покупателя.
export const TIER_DISCOUNTS: Record<CustomerTier, number> = {
  [CustomerTier.BRONZE]: 0.0,
  [CustomerTier.SILVER]: 0.05,
  [CustomerTier.GOLD]: 0.1,
};

// Доступные промокоды и их скидка.
export const PROMO_CODES: Record<string, number> = {
  WELCOME15: 0.15,
  SUMMER20: 0.2,
  STUDENT25: 0.25,
};

// Промокод STUDENT25 действует только на учебники.
export const STUDENT_PROMO_CATEGORY = BookCategory.TEXTBOOK;

// Доставка.
export const BASE_DELIVERY_FEE = 300;
export const FREE_DELIVERY_THRESHOLD = 3000;
export const DELIVERY_PER_100G_OVER_1KG = 1;

// НДС на книги.
export const VAT_RATE = 0.1;

// Ограничения заказа.
export const MAX_QUANTITY_PER_ITEM = 20;
export const ORDER_LIMIT_GOLD = 500_000;
export const ORDER_LIMIT_REGULAR = 100_000;

// Период распродажи «чёрная пятница» (включительно) и её скидка.
export const BLACK_FRIDAY_START: [number, number] = [11, 24];
export const BLACK_FRIDAY_END: [number, number] = [11, 30];
export const BLACK_FRIDAY_DISCOUNT = 0.3;

/** Округление денежной суммы до двух знаков. */
function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

/** Детализация итоговой стоимости заказа по составляющим. */
export class PriceBreakdown {
  constructor(
    public readonly subtotal: number,
    public readonly discountableSubtotal: number,
    public readonly nonDiscountableSubtotal: number,
    public readonly discountRate: number,
    public readonly discountAmount: number,
    public readonly subtotalAfterDiscount: number,
    public readonly deliveryFee: number,
    public readonly vat: number,
    public readonly total: number,
  ) {}
}

/** Расчёт стоимости заказа: скидки, доставка и налог. */
@Injectable()
export class PricingService {
  /** Посчитать полную стоимость заказа с разбивкой по составляющим. */
  calculateOrderTotal(order: Order, moment?: Date): PriceBreakdown {
    this.validateOrder(order);

    const at = moment ?? new Date();

    const discountable = this.discountableSubtotal(order.items);
    const nonDiscountable = this.nonDiscountableSubtotal(order.items);
    const subtotal = discountable + nonDiscountable;

    const discountRate = this.bestDiscountRate(order, at);
    const discountAmount = round2(discountable * discountRate);
    const subtotalAfterDiscount = subtotal - discountAmount;

    const deliveryFee = this.calculateDeliveryFee(
      order.items,
      subtotalAfterDiscount,
    );
    const vat = this.calculateVat(subtotalAfterDiscount);
    const total = subtotalAfterDiscount + deliveryFee + vat;

    return new PriceBreakdown(
      subtotal,
      discountable,
      nonDiscountable,
      discountRate,
      discountAmount,
      subtotalAfterDiscount,
      deliveryFee,
      vat,
      total,
    );
  }

  /**
   * Выбрать наибольшую из применимых скидок: по уровню, по промокоду и по
   * распродаже.
   */
  bestDiscountRate(order: Order, moment: Date): number {
    const tierDiscount = TIER_DISCOUNTS[order.customer.tier];
    const promoDiscount = this.applicablePromoDiscount(
      order.promoCode,
      order.items,
    );
    const blackFriday = PricingService.isBlackFriday(moment)
      ? BLACK_FRIDAY_DISCOUNT
      : 0;
    return Math.max(tierDiscount, promoDiscount, blackFriday);
  }

  /**
   * Скидка по промокоду. STUDENT25 действует, только если все позиции —
   * учебники. Для неизвестного кода бросает PricingError.
   */
  applicablePromoDiscount(
    promoCode: string | null,
    items: readonly CartItem[],
  ): number {
    if (promoCode === null) {
      return 0;
    }
    if (!(promoCode in PROMO_CODES)) {
      throw new PricingError(`Неизвестный промокод: ${promoCode}`);
    }

    const base = PROMO_CODES[promoCode];
    if (promoCode === 'STUDENT25') {
      const allTextbooks = items.every(
        (item) => item.book.category === STUDENT_PROMO_CATEGORY,
      );
      return allTextbooks ? base : 0;
    }
    return base;
  }

  /**
   * Стоимость доставки. Бесплатно при наличии детских книг или при сумме
   * заказа не ниже порога; иначе базовая ставка плюс надбавка за вес свыше
   * 1 кг.
   */
  calculateDeliveryFee(
    items: readonly CartItem[],
    subtotalAfterDiscount: number,
  ): number {
    if (this.hasChildrenBooks(items)) {
      return 0;
    }
    if (subtotalAfterDiscount >= FREE_DELIVERY_THRESHOLD) {
      return 0;
    }

    const weight = items.reduce(
      (sum, item) => sum + item.book.weightGrams * item.quantity,
      0,
    );
    let fee = BASE_DELIVERY_FEE;
    if (weight > 1000) {
      const extraBlocks = Math.floor((weight - 1000) / 100);
      fee += DELIVERY_PER_100G_OVER_1KG * extraBlocks;
    }
    return fee;
  }

  /** НДС на книги от переданной суммы. */
  calculateVat(amount: number): number {
    return round2(amount * VAT_RATE);
  }

  /**
   * Проверить заказ перед расчётом: непустой, покупатель не заблокирован,
   * количество в допустимых пределах, сумма в рамках лимита уровня.
   */
  validateOrder(order: Order): void {
    if (order.isEmpty) {
      throw new PricingError('Заказ не может быть пустым');
    }
    if (order.customer.isBlocked) {
      throw new PricingError('Покупатель заблокирован');
    }

    for (const item of order.items) {
      if (item.quantity <= 0) {
        throw new PricingError(
          `Количество должно быть положительным: ${item.book.isbn}`,
        );
      }
      if (item.quantity > MAX_QUANTITY_PER_ITEM) {
        throw new PricingError(
          `Превышен лимит количества (${MAX_QUANTITY_PER_ITEM}) для ${item.book.isbn}`,
        );
      }
    }

    const limit =
      order.customer.tier === CustomerTier.GOLD
        ? ORDER_LIMIT_GOLD
        : ORDER_LIMIT_REGULAR;
    if (order.subtotal > limit) {
      throw new PricingError(
        `Сумма заказа ${order.subtotal} превышает лимит ${limit}`,
      );
    }
  }

  /** Попадает ли момент в период распродажи «чёрная пятница». */
  static isBlackFriday(moment: Date): boolean {
    const month = moment.getMonth() + 1;
    const day = moment.getDate();
    const [sm, sd] = BLACK_FRIDAY_START;
    const [em, ed] = BLACK_FRIDAY_END;
    return (
      (month > sm || (month === sm && day >= sd)) &&
      (month < em || (month === em && day <= ed))
    );
  }

  /** Сумма позиций, к которым применимы скидки (все, кроме коллекционных). */
  private discountableSubtotal(items: readonly CartItem[]): number {
    return items
      .filter((item) => item.book.category !== BookCategory.RARE)
      .reduce((sum, item) => sum + item.lineTotal, 0);
  }

  /** Сумма коллекционных книг, на которые скидки не распространяются. */
  private nonDiscountableSubtotal(items: readonly CartItem[]): number {
    return items
      .filter((item) => item.book.category === BookCategory.RARE)
      .reduce((sum, item) => sum + item.lineTotal, 0);
  }

  /** Есть ли в заказе хотя бы одна детская книга. */
  private hasChildrenBooks(items: readonly CartItem[]): boolean {
    return items.some((item) => item.book.category === BookCategory.CHILDREN);
  }
}
