/** Адрес доставки заказа. */
export class Address {
  constructor(
    public readonly country: string,
    public readonly city: string,
    public readonly postalCode: string,
    public readonly street: string,
  ) {}
}
