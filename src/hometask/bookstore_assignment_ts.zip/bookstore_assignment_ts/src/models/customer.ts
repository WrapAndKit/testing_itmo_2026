export enum CustomerTier {
  BRONZE = 'BRONZE',
  SILVER = 'SILVER',
  GOLD = 'GOLD',
}

/** Покупатель магазина. */
export class Customer {
  constructor(
    public readonly customerId: string,
    public readonly name: string,
    public readonly email: string,
    public tier: CustomerTier = CustomerTier.BRONZE,
    public ordersLastYear: number = 0,
    public country: string = 'RU',
    public isBlocked: boolean = false,
  ) {}
}
