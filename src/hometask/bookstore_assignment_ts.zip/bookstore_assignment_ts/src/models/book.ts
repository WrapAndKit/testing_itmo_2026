export enum BookCategory {
  FICTION = 'FICTION',
  NON_FICTION = 'NON_FICTION',
  TEXTBOOK = 'TEXTBOOK',
  CHILDREN = 'CHILDREN',
  RARE = 'RARE',
}

/** Книга в каталоге магазина. Неизменяемая после создания. */
export class Book {
  constructor(
    public readonly isbn: string,
    public readonly title: string,
    public readonly author: string,
    public readonly category: BookCategory,
    public readonly basePrice: number,
    public readonly weightGrams: number,
    public readonly publicationYear: number,
  ) {}
}
