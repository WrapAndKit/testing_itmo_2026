import { Book } from './book';

/** Позиция в заказе: книга и её количество. */
export class CartItem {
  constructor(
    public readonly book: Book,
    public quantity: number,
  ) {}

  /** Стоимость позиции по базовой цене, без учёта скидок. */
  get lineTotal(): number {
    return this.book.basePrice * this.quantity;
  }
}
