import { Address } from './address';
import { CartItem } from './cart-item';
import { Customer } from './customer';

export enum OrderStatus {
  DRAFT = 'DRAFT',
  PENDING_PAYMENT = 'PENDING_PAYMENT',
  PAID = 'PAID',
  SHIPPED = 'SHIPPED',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED',
  REFUNDED = 'REFUNDED',
}

/** Заказ покупателя со списком позиций и текущим статусом. */
export class Order {
  status: OrderStatus = OrderStatus.DRAFT;
  promoCode: string | null = null;
  shippingAddress: Address | null = null;
  paymentTransactionId: string | null = null;
  readonly createdAt: Date = new Date();

  constructor(
    public readonly orderId: string,
    public readonly customer: Customer,
    public items: CartItem[] = [],
  ) {}

  /** Сумма всех позиций по базовым ценам, без скидок и доставки. */
  get subtotal(): number {
    return this.items.reduce((sum, item) => sum + item.lineTotal, 0);
  }

  /** Суммарный вес всех книг заказа в граммах. */
  get totalWeightGrams(): number {
    return this.items.reduce(
      (sum, item) => sum + item.book.weightGrams * item.quantity,
      0,
    );
  }

  /** True, если в заказе нет ни одной позиции. */
  get isEmpty(): boolean {
    return this.items.length === 0;
  }
}
