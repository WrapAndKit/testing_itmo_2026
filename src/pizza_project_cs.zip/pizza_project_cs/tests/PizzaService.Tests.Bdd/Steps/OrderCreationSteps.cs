using FluentAssertions;
using Reqnroll;

namespace PizzaService.Tests.Bdd.Steps;

/// <summary>
/// Step definitions для OrderCreation.feature.
///
/// Reqnroll синтаксис vs pytest-bdd/Cucumber.js:
///
///   pytest-bdd:    @given(parsers.parse('Клиент "{name}" ...'))
///   cucumber-js:   Given('Клиент {string} ...', function(name) {...})
///   Reqnroll:      [Given(@"Клиент ""(.*)"" ...")] public void Method(string name)
///
/// Шаблоны параметров — регулярные выражения. (.*) захватывает группу,
/// которая передаётся как аргумент метода.
/// </summary>
[Binding]
public sealed class OrderCreationSteps
{
    private readonly PizzaContext _ctx;

    public OrderCreationSteps(PizzaContext ctx) => _ctx = ctx;

    // ═══════════════════════════════════════════════════════════════
    //  GIVEN
    // ═══════════════════════════════════════════════════════════════

    [Given(@"Клиент ""(.*)"" создаёт новый заказ")]
    public void GivenCustomerCreatesNewOrder(string name)
    {
        var customer = new Customer
        {
            Name = name,
            Phone = "+7-000-000-0000",
            IsLoyal = false,
            OrdersCompleted = 0,
        };
        _ctx.Customer = customer;
        _ctx.Order = new Order(customer);
    }

    [Given(@"Зарегистрирован постоянный клиент ""(.*)""")]
    public void GivenLoyalCustomer(string name)
    {
        var customer = new Customer
        {
            Name = name,
            Phone = "+7-000-000-0000",
            IsLoyal = true,
            OrdersCompleted = 20,
        };
        _ctx.Customer = customer;
        _ctx.Order = new Order(customer);
    }

    [Given(@"Клиент добавил в заказ пиццу ""(.*)"" размера ""(.*)""")]
    public void GivenCustomerAddedPizza(string pizzaName, string size)
    {
        var pizza = Catalog.All[pizzaName];
        var sizeEnum = Enum.Parse<PizzaSize>(size);
        _ctx.OrderService.AddItem(_ctx.Order!, pizza, sizeEnum, 1);
    }

    [Given(@"Клиент добавил в заказ пиццу ""(.*)"" размера ""(.*)"" в количестве (\d+)")]
    public void GivenCustomerAddedPizzaQty(string pizzaName, string size, int qty)
    {
        var pizza = Catalog.All[pizzaName];
        var sizeEnum = Enum.Parse<PizzaSize>(size);
        _ctx.OrderService.AddItem(_ctx.Order!, pizza, sizeEnum, qty);
    }

    // ═══════════════════════════════════════════════════════════════
    //  WHEN
    // ═══════════════════════════════════════════════════════════════

    [When(@"Клиент добавляет в заказ пиццу ""(.*)"" размера ""(.*)""")]
    public void WhenCustomerAddsPizza(string pizzaName, string size)
    {
        var pizza = Catalog.All[pizzaName];
        var sizeEnum = Enum.Parse<PizzaSize>(size);
        _ctx.OrderService.AddItem(_ctx.Order!, pizza, sizeEnum, 1);
    }

    [When(@"Клиент добавляет в заказ пиццу ""(.*)"" размера ""(.*)"" в количестве (\d+)")]
    public void WhenCustomerAddsPizzaQty(string pizzaName, string size, int qty)
    {
        var pizza = Catalog.All[pizzaName];
        var sizeEnum = Enum.Parse<PizzaSize>(size);
        _ctx.OrderService.AddItem(_ctx.Order!, pizza, sizeEnum, qty);
    }

    [When(@"Клиент применяет промокод ""(.*)""")]
    public void WhenCustomerAppliesPromo(string code)
    {
        _ctx.OrderService.ApplyPromo(_ctx.Order!, code);
    }

    [When(@"Клиент подтверждает заказ в (\d+):(\d+)")]
    public void WhenCustomerConfirmsAt(int hh, int mm)
    {
        var moment = new DateTime(2025, 5, 14, hh, mm, 0);
        _ctx.Total = _ctx.OrderService.Confirm(_ctx.Order!, moment);
    }

    [When(@"Клиент оформляет заказ из пиццы ""(.*)"" размера ""(.*)""")]
    public void WhenCustomerPlacesOrder(string pizzaName, string size)
    {
        var pizza = Catalog.All[pizzaName];
        var sizeEnum = Enum.Parse<PizzaSize>(size);
        _ctx.OrderService.AddItem(_ctx.Order!, pizza, sizeEnum, 1);
    }

    [When(@"Клиент пытается подтвердить пустой заказ")]
    public void WhenCustomerTriesConfirmEmpty()
    {
        try
        {
            _ctx.OrderService.Confirm(_ctx.Order!);
        }
        catch (Exception e)
        {
            _ctx.Exception = e;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  THEN
    // ═══════════════════════════════════════════════════════════════

    [Then(@"В заказе должно быть (\d+) позиции")]
    [Then(@"В заказе должно быть (\d+) позиций")]
    public void ThenItemsCount(int n)
    {
        _ctx.Order!.Items.Count.Should().Be(n);
    }

    [Then(@"Сумма заказа без скидок составляет (\d+) руб\.")]
    public void ThenSubtotalEquals(int amount)
    {
        _ctx.Order!.Subtotal.Should().Be(amount);
    }

    [Then(@"Сумма к оплате составит (\d+) руб\.")]
    public void ThenTotalEquals(int amount)
    {
        _ctx.Total.Should().Be(amount);
    }

    [Then(@"Заказ переходит в статус ""(.*)""")]
    public void ThenOrderStatus(string status)
    {
        _ctx.Order!.Status.Should().Be(Enum.Parse<OrderStatus>(status));
    }

    [Then(@"Применяется скидка постоянного клиента 10%")]
    public void ThenLoyalDiscountApplied()
    {
        var subtotal = _ctx.Order!.Subtotal;
        var expectedAfterDiscount = subtotal * 0.9m;
        var expectedTotal = expectedAfterDiscount >= 1500m
            ? expectedAfterDiscount
            : expectedAfterDiscount + 200m;
        _ctx.Total.Should().Be(expectedTotal);
    }

    [Then(@"Доставка должна быть бесплатной")]
    public void ThenFreeDelivery()
    {
        _ctx.Total.Should().BeLessThanOrEqualTo(_ctx.Order!.Subtotal);
    }

    [Then(@"К сумме добавляется стоимость доставки (\d+) руб\.")]
    public void ThenDeliveryFeeAdded(int fee)
    {
        _ctx.Total.Should().BeGreaterThanOrEqualTo(_ctx.Order!.Subtotal);
    }

    [Then(@"Система отклоняет операцию с сообщением ""(.*)""")]
    public void ThenOperationRejected(string msg)
    {
        _ctx.Exception.Should().NotBeNull();
        _ctx.Exception!.Message.Should().Contain(msg);
    }
}
