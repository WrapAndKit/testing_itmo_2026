namespace PizzaService.Tests.Bdd.Steps;

/// <summary>
/// Контекст одного сценария — состояние между шагами.
///
/// Reqnroll создаёт новый экземпляр перед каждым сценарием через
/// встроенный DI-контейнер. Это аналог фикстуры context в pytest-bdd
/// и World class в Cucumber.js.
///
/// Регистрация происходит автоматически: класс инжектируется в
/// конструкторы step-классов через [Binding].
/// </summary>
public sealed class PizzaContext
{
    public PricingService Pricing { get; } = new();
    public OrderService OrderService { get; }

    public Customer? Customer { get; set; }
    public Order? Order { get; set; }
    public decimal? Total { get; set; }
    public DateTime? Moment { get; set; }
    public Exception? Exception { get; set; }
    public decimal? Subtotal { get; set; }

    public PizzaContext()
    {
        OrderService = new OrderService(Pricing);
    }
}
