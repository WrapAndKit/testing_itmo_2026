using FluentAssertions;
using Reqnroll;

namespace PizzaService.Tests.Bdd.Steps;

/// <summary>
/// Step definitions для Discounts.feature.
/// Демонстрирует Scenario Outline — параметризованный сценарий.
/// </summary>
[Binding]
public sealed class DiscountSteps
{
    private readonly PizzaContext _ctx;

    public DiscountSteps(PizzaContext ctx) => _ctx = ctx;

    // ═══════════════════════════════════════════════════════════════
    //  Шаги для Scenario Outline
    // ═══════════════════════════════════════════════════════════════

    [Given(@"Клиент с признаком ""(.*)"" оформил заказ на (\d+) руб\.")]
    public void GivenCustomerWithLoyaltyAndAmount(string loyalty, int amount)
    {
        var isLoyal = loyalty.ToLower() == "да";
        var customer = new Customer
        {
            Name = "Тестовый клиент",
            Phone = "+7",
            IsLoyal = isLoyal,
            OrdersCompleted = 0,
        };
        var order = new Order(customer);

        // Искусственная пицца с нужной базовой ценой
        var pizza = new Pizza("Test Pizza", amount, IsVegetarian: false);
        order.Items.Add(new OrderItem(pizza, PizzaSize.MEDIUM, 1));

        _ctx.Order = order;
        _ctx.Subtotal = amount;
    }

    [Given(@"Применил промокод ""(.*)""")]
    public void GivenAppliedPromo(string code)
    {
        if (code.ToLower() != "нет")
        {
            _ctx.Order!.PromoCode = code;
        }
    }

    [Given(@"Заказ оформлен в ""(\d+):(\d+)""")]
    public void GivenOrderPlacedAt(int hh, int mm)
    {
        _ctx.Moment = new DateTime(2025, 5, 14, hh, mm, 0);
    }

    [When(@"Рассчитывается итоговая сумма")]
    public void WhenCalculateTotal()
    {
        _ctx.Total = _ctx.Pricing.CalculateTotal(_ctx.Order!, _ctx.Moment);
    }

    [Then(@"Применённая скидка составляет (\d+)%")]
    public void ThenAppliedDiscount(int percent)
    {
        var subtotal = _ctx.Subtotal!.Value;
        var afterDiscount = subtotal - subtotal * (percent / 100m);
        var expectedTotal = afterDiscount >= 1500m
            ? afterDiscount
            : afterDiscount + 200m;

        _ctx.Total.Should().Be(
            expectedTotal,
            $"Ожидали {expectedTotal} (скидка {percent}%), получили {_ctx.Total}");
    }

    // ═══════════════════════════════════════════════════════════════
    //  Шаги для обычного сценария — попытка плохого промокода
    // ═══════════════════════════════════════════════════════════════

    [When(@"Клиент пытается применить промокод ""(.*)""")]
    public void WhenCustomerTriesPromo(string code)
    {
        try
        {
            _ctx.OrderService.ApplyPromo(_ctx.Order!, code);
        }
        catch (Exception e)
        {
            _ctx.Exception = e;
        }
    }
}
