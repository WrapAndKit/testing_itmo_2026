using CsCheck;
using FluentAssertions;
using Xunit;

namespace PizzaService.Tests.Property;

/// <summary>
/// Property-based тесты на CsCheck.
///
/// Аналогии Hypothesis (Python) → CsCheck (C#):
///   @given(st.integers())          Gen.Int
///   st.sampled_from(list)          Gen.OneOf / Gen.OneOfConst
///   st.lists(s, min_size=1)        Gen.List.[Min/Max]
///   assume(cond)                   Where(...) или Sample(predicate)
///   @composite                     Gen.Select
///
/// Запуск свойства: gen.Sample(predicate).
/// CsCheck автоматически делает shrinking при падении.
/// </summary>
public class PricingPropertyTests
{
    private static readonly Gen<string> PizzaNames =
        Gen.OneOfConst("Маргарита", "Пепперони", "Четыре сыра", "Гавайская");

    private static readonly Gen<PizzaSize> PizzaSizes =
        Gen.OneOfConst(PizzaSize.SMALL, PizzaSize.MEDIUM, PizzaSize.LARGE);

    private static readonly Gen<int> Quantities = Gen.Int[1, 10];

    private static readonly Gen<OrderItem> OrderItems = Gen.Select(
        PizzaNames, PizzaSizes, Quantities,
        (name, size, qty) => new OrderItem(Catalog.All[name], size, qty));

    // Параметризованная стратегия: с фиксированным loyal/promo или случайными
    private static Gen<Order> OrdersGen(bool? isLoyal = null, bool? withPromo = null)
    {
        var loyalGen = isLoyal is not null ? Gen.Const(isLoyal.Value) : Gen.Bool;
        var promoGen = withPromo switch
        {
            false => Gen.Const<string?>(null),
            true => Gen.OneOfConst("WELCOME10", "SUMMER20", "VIP30")
                       .Select<string, string?>(p => p),
            null => Gen.OneOf(
                Gen.Const<string?>(null),
                Gen.OneOfConst("WELCOME10", "SUMMER20", "VIP30").Select<string, string?>(p => p)
            ),
        };
        var itemsGen = Gen.List(OrderItems, 1, 5);

        return Gen.Select(loyalGen, itemsGen, promoGen, (loyal, items, promo) =>
        {
            var customer = new Customer
            {
                Name = "Test", Phone = "+7", IsLoyal = loyal, OrdersCompleted = 0,
            };
            var order = new Order(customer);
            foreach (var item in items)
                order.Items.Add(item);
            order.PromoCode = promo;
            return order;
        });
    }

    private static readonly DateTime Midday = new(2025, 5, 14, 12, 0, 0);

    // ═══════════════════════════════════════════════════════════════
    //  Свойства цены
    // ═══════════════════════════════════════════════════════════════

    [Fact]
    public void Total_is_never_negative()
    {
        var pricing = new PricingService();
        OrdersGen().Sample(order =>
        {
            var total = pricing.CalculateTotal(order, Midday);
            return total >= 0m;
        });
    }

    [Fact]
    public void Total_at_most_subtotal_plus_delivery()
    {
        var pricing = new PricingService();
        OrdersGen().Sample(order =>
        {
            var total = pricing.CalculateTotal(order, Midday);
            var maxPossible = order.Subtotal + PricingService.DeliveryFee;
            return total <= maxPossible;
        });
    }

    [Fact]
    public void No_loyalty_no_promo_no_happy_hour_means_no_savings()
    {
        var pricing = new PricingService();
        OrdersGen(isLoyal: false, withPromo: false).Sample(order =>
        {
            var total = pricing.CalculateTotal(order, Midday);
            var expectedDelivery = order.Subtotal >= PricingService.FreeDeliveryThreshold
                ? 0m
                : PricingService.DeliveryFee;
            return total == order.Subtotal + expectedDelivery;
        });
    }

    [Fact]
    public void Loyal_pays_no_more_than_regular_for_large_orders()
    {
        // Изначально хотелось: "loyal клиент платит ≤ обычного".
        // Но property-based нашёл контрпример: subtotal=1560 (выше порога 1500),
        // loyal после скидки = 1404 (упало ниже!) + 200 доставка = 1604.
        // Regular: 1560 + 0 = 1560. Loyal заплатил больше из-за границы доставки.
        // Поэтому свойство строже — для заказов с запасом от порога.
        var pricing = new PricingService();

        OrdersGen(isLoyal: true, withPromo: false)
            .Where(o => o.Subtotal >= 1700m)   // запас от порога
            .Sample(loyalOrder =>
            {
                var loyalTotal = pricing.CalculateTotal(loyalOrder, Midday);

                // Тот же заказ, но customer не loyal
                var regularCustomer = new Customer
                {
                    Name = loyalOrder.Customer.Name,
                    Phone = loyalOrder.Customer.Phone,
                    IsLoyal = false,
                    OrdersCompleted = loyalOrder.Customer.OrdersCompleted,
                };
                var regularOrder = new Order(regularCustomer);
                foreach (var item in loyalOrder.Items)
                    regularOrder.Items.Add(item);

                var regularTotal = pricing.CalculateTotal(regularOrder, Midday);

                return loyalTotal <= regularTotal;
            });
    }

    // ═══════════════════════════════════════════════════════════════
    //  Свойства OrderService
    // ═══════════════════════════════════════════════════════════════

    [Fact]
    public void Non_positive_quantity_rejected()
    {
        var orderService = new OrderService(new PricingService());

        Gen.Int[-100, 0].Sample(qty =>
        {
            var customer = new Customer { Name = "X", Phone = "+7" };
            var order = new Order(customer);

            try
            {
                orderService.AddItem(order, Catalog.Margherita, PizzaSize.MEDIUM, qty);
                return false; // должно было выбросить
            }
            catch (ArgumentException)
            {
                return true;
            }
        });
    }

    [Fact]
    public void Add_then_remove_preserves_count()
    {
        var orderService = new OrderService(new PricingService());

        Gen.List(OrderItems, 1, 10).Sample(items =>
        {
            var customer = new Customer { Name = "X", Phone = "+7" };
            var order = new Order(customer);

            foreach (var item in items)
                orderService.AddItem(order, item.Pizza, item.Size, item.Quantity);

            var countBefore = order.Items.Count;

            orderService.AddItem(order, Catalog.Margherita, PizzaSize.MEDIUM, 1);
            orderService.RemoveItem(order, order.Items.Count - 1);

            return order.Items.Count == countBefore;
        });
    }

    // ═══════════════════════════════════════════════════════════════
    //  Where() — фильтрация (аналог assume() / fc.pre())
    // ═══════════════════════════════════════════════════════════════

    [Fact]
    public void Free_delivery_when_above_threshold()
    {
        var pricing = new PricingService();

        OrdersGen(isLoyal: false, withPromo: false)
            .Where(o => o.Subtotal >= PricingService.FreeDeliveryThreshold)
            .Sample(order =>
            {
                var total = pricing.CalculateTotal(order, Midday);
                return total == order.Subtotal;
            });
    }

    // ═══════════════════════════════════════════════════════════════
    //  Свойства lineTotal
    // ═══════════════════════════════════════════════════════════════

    [Fact]
    public void LineTotal_is_always_positive()
    {
        OrderItems.Sample(item => item.LineTotal > 0);
    }

    [Fact]
    public void LineTotal_is_linear_in_quantity()
    {
        Gen.Select(PizzaNames, PizzaSizes, Gen.Int[1, 5], Gen.Int[1, 5])
            .Sample((name, size, q1, q2) =>
            {
                var pizza = Catalog.All[name];
                var single = new OrderItem(pizza, size, 1).LineTotal;
                var total = new OrderItem(pizza, size, q1 + q2).LineTotal;
                return total == single * (q1 + q2);
            });
    }
}
