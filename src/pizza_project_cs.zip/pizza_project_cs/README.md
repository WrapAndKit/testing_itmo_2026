## Быстрый старт

```bash
cd pizza_project_cs
dotnet restore
dotnet test
```

Ожидается: 19 BDD-сценариев + 8 property-based.

## Стек

- **.NET 8**
- **Reqnroll** — преемник SpecFlow (активно поддерживается), BDD на Gherkin
- **xUnit** — runner для property-based и для самого Reqnroll
- **CsCheck** — property-based фреймворк
- **FluentAssertions** — читаемые ассерты
- **Stryker.NET** — мутационное тестирование

## Аналогии Python ↔ TypeScript ↔ C#

### BDD

| pytest-bdd | Cucumber.js | Reqnroll |
|------------|-------------|----------|
| `@given(parsers.parse('Клиент "{name}" ...'))` | `Given('Клиент {string} ...', fn)` | `[Given(@"Клиент ""(.*)"" ...")]` |
| Параметр `{name}` (parser) | `{string}`, `{int}` | `(.*)`, `(\d+)` (regex) |
| Фикстура `context` (dict) | World class | DI-инжектируемый класс контекста |
| `scenarios("../features/...")` | `cucumber.js` config | `.feature` в одном проекте |

### Property-based

| Hypothesis | fast-check | CsCheck |
|------------|------------|---------|
| `@given(st.integers())` | `fc.assert(fc.property(fc.integer(), ...))` | `Gen.Int.Sample(predicate)` |
| `st.sampled_from(list)` | `fc.constantFrom(...list)` | `Gen.OneOfConst(...)` |
| `st.lists(s, min_size=1)` | `fc.array(s, { minLength: 1 })` | `Gen.List(s, min, max)` |
| `assume(cond)` | `fc.pre(cond)` | `.Where(cond)` |
| `@composite` | `fc.record({...})` | `Gen.Select(...)` |

### Мутационное

| mutmut | Stryker (JS/TS) | Stryker.NET |
|--------|-----------------|-------------|
| `mutmut run` | `npx stryker run` | `dotnet stryker` |
| `mutmut results` | HTML отчёт | HTML отчёт |
| `mutmut show <id>` | В HTML | В HTML |

## Команды

```bash
# Все тесты
dotnet test

# Только BDD
dotnet test tests/PizzaService.Tests.Bdd/

# Только property-based
dotnet test tests/PizzaService.Tests.Property/

# Конкретный сценарий
dotnet test --filter "FullyQualifiedName~OrderCreation"

# С покрытием
dotnet test --collect:"XPlat Code Coverage"

# Мутационное тестирование (установить инструмент один раз)
dotnet tool install -g dotnet-stryker
cd tests/PizzaService.Tests.Property
dotnet stryker
```

## Особенности C#-версии

### Контекст через DI

Reqnroll использует встроенный контейнер инверсии зависимостей: `PizzaContext` инжектируется в конструктор каждого step-класса. Это аналог Cucumber.js World и фикстуры context в pytest-bdd, только статически типизированный.

### Параметры в шагах — регулярные выражения

В отличие от pytest-bdd `{name}` и Cucumber.js `{string}`, Reqnroll использует **регулярные выражения**:
- `(.*)` — любая строка
- `(\d+)` — целое число
- `([^"]*)` — строка без кавычек

В кавычки нужно класть параметры явно — `"(.*)"`.
