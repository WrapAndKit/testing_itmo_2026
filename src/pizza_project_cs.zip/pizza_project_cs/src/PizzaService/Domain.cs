namespace PizzaService;

public enum PizzaSize { SMALL, MEDIUM, LARGE }

public enum OrderStatus
{
    DRAFT,
    CONFIRMED,
    COOKING,
    READY,
    DELIVERED,
    CANCELLED,
}

public sealed record Pizza(string Name, decimal BasePrice, bool IsVegetarian);

public sealed class OrderItem
{
    public Pizza Pizza { get; }
    public PizzaSize Size { get; }
    public int Quantity { get; }

    public OrderItem(Pizza pizza, PizzaSize size, int quantity = 1)
    {
        Pizza = pizza;
        Size = size;
        Quantity = quantity;
    }

    public decimal LineTotal
    {
        get
        {
            var multiplier = Size switch
            {
                PizzaSize.SMALL => 0.8m,
                PizzaSize.MEDIUM => 1.0m,
                PizzaSize.LARGE => 1.3m,
                _ => 1.0m,
            };
            return Pizza.BasePrice * multiplier * Quantity;
        }
    }
}

public sealed class Customer
{
    public string Name { get; init; } = "";
    public string Phone { get; init; } = "";
    public bool IsLoyal { get; init; }
    public int OrdersCompleted { get; init; }
}

public sealed class Order
{
    public Customer Customer { get; }
    public List<OrderItem> Items { get; } = new();
    public OrderStatus Status { get; internal set; } = OrderStatus.DRAFT;
    public string? PromoCode { get; internal set; }
    public DateTime CreatedAt { get; } = DateTime.Now;

    public Order(Customer customer) => Customer = customer;

    public decimal Subtotal => Items.Sum(i => i.LineTotal);
    public bool IsEmpty => Items.Count == 0;
}

// ═════════════════════════════════════════════════════════════════
//  Сервис расчёта стоимости
// ═════════════════════════════════════════════════════════════════

public sealed class PricingService
{
    public const decimal DeliveryFee = 200m;
    public const decimal FreeDeliveryThreshold = 1500m;
    public const decimal LoyalDiscount = 0.10m;
    public const decimal HappyHourDiscount = 0.15m;

    public static readonly IReadOnlyDictionary<string, decimal> PromoCodes =
        new Dictionary<string, decimal>
        {
            ["WELCOME10"] = 0.10m,
            ["SUMMER20"] = 0.20m,
            ["VIP30"] = 0.30m,
        };

    /// <summary>
    /// Итог = subtotal − лучшая скидка + доставка (если применима).
    /// Применяется максимум одна (самая выгодная) скидка.
    /// </summary>
    public decimal CalculateTotal(Order order, DateTime? now = null)
    {
        if (order.IsEmpty)
            throw new InvalidOperationException(
                "Невозможно рассчитать стоимость пустого заказа");

        var subtotal = order.Subtotal;
        decimal bestDiscount = 0m;

        if (order.Customer.IsLoyal)
            bestDiscount = Math.Max(bestDiscount, LoyalDiscount);

        if (order.PromoCode != null && PromoCodes.TryGetValue(order.PromoCode, out var promo))
            bestDiscount = Math.Max(bestDiscount, promo);

        var moment = now ?? DateTime.Now;
        if (moment.Hour >= 14 && moment.Hour < 17)
            bestDiscount = Math.Max(bestDiscount, HappyHourDiscount);

        var afterDiscount = subtotal - subtotal * bestDiscount;
        var delivery = afterDiscount >= FreeDeliveryThreshold ? 0m : DeliveryFee;

        return afterDiscount + delivery;
    }
}

// ═════════════════════════════════════════════════════════════════
//  Сервис управления заказами
// ═════════════════════════════════════════════════════════════════

public sealed class OrderService
{
    private readonly PricingService _pricing;

    public OrderService(PricingService pricing) => _pricing = pricing;

    public void AddItem(Order order, Pizza pizza, PizzaSize size, int quantity = 1)
    {
        if (quantity <= 0)
            throw new ArgumentException("Количество должно быть положительным");
        if (order.Status != OrderStatus.DRAFT)
            throw new InvalidOperationException(
                $"Нельзя изменить заказ в статусе {order.Status}");
        order.Items.Add(new OrderItem(pizza, size, quantity));
    }

    public void RemoveItem(Order order, int index)
    {
        if (order.Status != OrderStatus.DRAFT)
            throw new InvalidOperationException("Нельзя изменить подтверждённый заказ");
        if (index < 0 || index >= order.Items.Count)
            throw new ArgumentOutOfRangeException(
                nameof(index), $"Нет позиции с индексом {index}");
        order.Items.RemoveAt(index);
    }

    public void ApplyPromo(Order order, string code)
    {
        if (order.Status != OrderStatus.DRAFT)
            throw new InvalidOperationException("Промокод можно применить только к черновику");
        if (!PricingService.PromoCodes.ContainsKey(code))
            throw new ArgumentException($"Неизвестный промокод: {code}");
        order.PromoCode = code;
    }

    public decimal Confirm(Order order, DateTime? now = null)
    {
        if (order.IsEmpty)
            throw new InvalidOperationException("Нельзя подтвердить пустой заказ");
        if (order.Status != OrderStatus.DRAFT)
            throw new InvalidOperationException(
                $"Заказ уже в статусе {order.Status}");

        var total = _pricing.CalculateTotal(order, now);
        order.Status = OrderStatus.CONFIRMED;
        return total;
    }

    public void Cancel(Order order)
    {
        if (order.Status is OrderStatus.DELIVERED or OrderStatus.CANCELLED)
            throw new InvalidOperationException(
                $"Нельзя отменить заказ в статусе {order.Status}");
        order.Status = OrderStatus.CANCELLED;
    }
}

// ═════════════════════════════════════════════════════════════════
//  Каталог пицц
// ═════════════════════════════════════════════════════════════════

public static class Catalog
{
    public static readonly Pizza Margherita = new("Маргарита", 450m, IsVegetarian: true);
    public static readonly Pizza Pepperoni = new("Пепперони", 550m, IsVegetarian: false);
    public static readonly Pizza QuattroFormaggi = new("Четыре сыра", 650m, IsVegetarian: true);
    public static readonly Pizza Hawaiian = new("Гавайская", 600m, IsVegetarian: false);

    public static readonly IReadOnlyDictionary<string, Pizza> All =
        new Dictionary<string, Pizza>
        {
            ["Маргарита"] = Margherita,
            ["Пепперони"] = Pepperoni,
            ["Четыре сыра"] = QuattroFormaggi,
            ["Гавайская"] = Hawaiian,
        };
}
