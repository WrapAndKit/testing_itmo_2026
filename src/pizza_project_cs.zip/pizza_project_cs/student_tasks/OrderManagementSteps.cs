using FluentAssertions;
using Reqnroll;

namespace PizzaService.Tests.Bdd.StudentTasks;

/// <summary>
///
/// Задача: дописать step definitions для OrderManagement.feature.
/// Эталон: tests/PizzaService.Tests.Bdd/Steps/OrderCreationSteps.cs
///
/// Как запустить:
///   dotnet test --filter "FullyQualifiedName~OrderManagement"
/// </summary>
[Binding]
public sealed class OrderManagementSteps
{
    private readonly Steps.PizzaContext _ctx;

    public OrderManagementSteps(Steps.PizzaContext ctx) => _ctx = ctx;

    // ═══════════════════════════════════════════════════════════════
    //  Готовый шаг — пример для подражания
    // ═══════════════════════════════════════════════════════════════

    [Given(@"Клиент создал заказ с пиццей ""(.*)"" размера ""(.*)""")]
    public void GivenCustomerCreatedOrderWith(string pizzaName, string size)
    {
        var customer = new Customer { Name = "Тест", Phone = "+7" };
        var order = new Order(customer);
        var pizza = Catalog.All[pizzaName];
        var sizeEnum = Enum.Parse<PizzaSize>(size);
        _ctx.OrderService.AddItem(order, pizza, sizeEnum, 1);
        _ctx.Order = order;
    }

    // ═══════════════════════════════════════════════════════════════
    //  TODO: реализовать остальные шаги
    // ═══════════════════════════════════════════════════════════════

    // TODO: [Given(@"Клиент добавил пиццу ""(.*)"" размера ""(.*)""")]
    //       — добавляет в существующий _ctx.Order

    // TODO: [Given(@"Клиент оформил и подтвердил заказ на сумму (\d+) руб\.")]
    //       — создать заказ и сразу подтвердить

    // TODO: [When(@"Клиент удаляет позицию с индексом (\d+)")]

    // TODO: [When(@"Клиент отменяет заказ")]

    // TODO: [Then(@"В заказе остаётся (\d+) позиция")]
    // TODO: [Then(@"В заказе остаётся (\d+) позиции")]

    // TODO: [Then(@"Оставшаяся позиция — ""(.*)""")]

    // TODO: [Then(@"Заказ переходит в статус ""(.*)""")]
    //       — уже есть в OrderCreationSteps, можно переиспользовать —
    //       если оставить тот же — Reqnroll возьмёт первое совпадение
}
