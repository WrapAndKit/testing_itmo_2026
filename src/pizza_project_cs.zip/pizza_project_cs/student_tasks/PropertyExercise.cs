using CsCheck;
using FluentAssertions;
using Xunit;

namespace PizzaService.Tests.Property.StudentTasks;

/// <summary>
///
/// Задача: написать property-based тесты с CsCheck.
/// Эталон: tests/PizzaService.Tests.Property/PricingPropertyTests.cs
///
/// Как запустить:
///   dotnet test --filter "FullyQualifiedName~StudentTasks.PropertyExercise"
/// </summary>
public class PropertyExercise
{
    private static readonly Gen<string> PizzaNames =
        Gen.OneOfConst("Маргарита", "Пепперони", "Четыре сыра", "Гавайская");

    private static readonly Gen<PizzaSize> PizzaSizes =
        Gen.OneOfConst(PizzaSize.SMALL, PizzaSize.MEDIUM, PizzaSize.LARGE);

    // ══════════════════════════════════════════════════════════════════
    //  СВОЙСТВО 1. Промокод не увеличивает сумму
    // ══════════════════════════════════════════════════════════════════

    [Fact]
    public void Promo_never_increases_total()
    {
        // TODO:
        //   1. Создать генератор с PizzaNames и PizzaSizes через Gen.Select
        //   2. .Sample((name, size) => { ... })
        //   3. Внутри: создать customer (не loyal), order с одной пиццей
        //   4. Запомнить total без промокода
        //   5. Применить WELCOME10 → посчитать total с промокодом
        //   6. Вернуть totalWithPromo <= totalWithoutPromo
        Assert.True(true);   // заменить
    }

    // ══════════════════════════════════════════════════════════════════
    //  СВОЙСТВО 2. Положительная стоимость
    // ══════════════════════════════════════════════════════════════════

    [Fact]
    public void Total_is_always_positive_for_non_empty_order()
    {
        // TODO:
        //   1. Gen.Int[1, 5].Sample(count => { ... })
        //   2. Создать заказ с count позициями
        //   3. Вернуть pricing.CalculateTotal(order, midday) > 0
        Assert.True(true);
    }

    // ══════════════════════════════════════════════════════════════════
    //  СВОЙСТВО 3. Бесплатная доставка с порога
    // ══════════════════════════════════════════════════════════════════

    [Fact]
    public void Free_delivery_at_threshold()
    {
        // TODO:
        //   Используйте .Where() для отсечения случаев < 1500.
        //   Проверить: total == subtotal
        Assert.True(true);
    }
}
