"""
СТАРТОВЫЙ ФАЙЛ — Занятие 1, Упражнение 1.

Задача: дописать тесты для функции assign_grade из src/grading.py.
Эталонное решение: tests/unit/test_grading.py

Как запустить:
    pytest student_tasks/exercise_1_grading.py -v
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from grading import assign_grade


class TestAssignGradePositive:
    """Позитивные сценарии: середины классов эквивалентности."""

    def test_score_20_returns_F(self):
        """TC-01: Середина класса F (0–39)."""
        # Arrange
        score = 20
        # Act
        result = assign_grade(score)
        # Assert
        assert result == "F"

    def test_score_50_returns_D(self):
        """TC-02: Середина класса D (40–59)."""
        # TODO: напишите тест по образцу выше
        ...

    def test_score_67_returns_C(self):
        """TC-03: Середина класса C (60–74)."""
        # TODO: напишите тест
        ...

    def test_score_82_returns_B(self):
        """TC-04: Середина класса B (75–89)."""
        # TODO: напишите тест
        ...

    def test_score_95_returns_A(self):
        """TC-05: Середина класса A (90–100)."""
        # TODO: напишите тест
        ...


class TestAssignGradeBoundary:
    """Граничные значения на стыках классов."""

    def test_F_D_boundary_below(self):
        """TC-10: 39 — последнее значение для F."""
        assert assign_grade(39) == "F"

    def test_F_D_boundary_above(self):
        """TC-11: 40 — первое значение для D."""
        # TODO
        ...

    # TODO: добавьте тесты для границ D/C (59, 60), C/B (74, 75), B/A (89, 90)


class TestAssignGradeNegative:
    """Негативные сценарии."""

    def test_negative_score_raises(self):
        """TC-08: Отрицательный балл → ValueError."""
        with pytest.raises(ValueError, match="от 0 до 100"):
            assign_grade(-1)

    def test_over_100_raises(self):
        """TC-09: Больше 100 → ValueError."""
        # TODO: напишите тест с pytest.raises
        ...

    def test_float_raises_type_error(self):
        """TC-23: Дробное число → TypeError."""
        # TODO
        ...


class TestAssignGradeOlympiad:
    """Олимпиадный бонус +1 к оценке."""

    def test_olympiad_F_becomes_D(self):
        """TC-18: Олимпиадник с F → D."""
        assert assign_grade(20, is_olympiad_winner=True) == "D"

    # TODO: добавьте тесты:
    #   - олимпиадник с D → C
    #   - олимпиадник с C → B
    #   - олимпиадник с B → A
    #   - олимпиадник с A → A (не повышается)
