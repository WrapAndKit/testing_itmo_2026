"""
ДОМАШНЕЕ ЗАДАНИЕ — после Занятия 2.

Задача:
    Написать полный набор тестов для корзины покупок (src/cart.py).
    Требования:
        - Использовать фикстуры (минимум 3)
        - Применить параметризацию (хотя бы для промокодов)
        - Разметить тесты маркерами smoke/boundary/negative
        - Добиться покрытия ≥ 95%
        - Минимум 15 тест-кейсов

Эталон: tests/unit/test_cart.py

Как проверить:
    pytest student_tasks/homework_cart.py -v
    pytest student_tasks/homework_cart.py --cov=src.cart --cov-report=term-missing

Критерии оценки:
    [ ] ≥ 15 тест-кейсов
    [ ] ≥ 3 фикстуры (пустая корзина, корзина с товарами, товары)
    [ ] Параметризация для промокодов SAVE10/SAVE20/HALF
    [ ] Маркеры smoke, boundary, negative использованы
    [ ] Покрытие ≥ 95% (branch coverage)
    [ ] Все тесты проходят
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from cart import Cart, Product


# ══════════════════════════════════════════════════════════════
#  ФИКСТУРЫ (3+)
# ══════════════════════════════════════════════════════════════


@pytest.fixture
def product_book():
    """Товар 'Книга' — 500 руб., 10 на складе."""
    return Product(name="Книга", price=500.0, stock=10)


# TODO: добавьте фикстуры product_pen, product_laptop, empty_cart, cart_with_items


# ══════════════════════════════════════════════════════════════
#  ТЕСТЫ
# ══════════════════════════════════════════════════════════════


class TestCartAdd:
    """Добавление товаров."""

    @pytest.mark.smoke
    def test_add_single_item(self, empty_cart, product_book):
        """Добавление одного товара."""
        # TODO
        ...

    # TODO: тесты на добавление нескольких единиц,
    #       разных товаров, превышение склада (negative),
    #       ровно по складу (boundary), и т.д.


class TestCartPromo:
    """Промокоды — используйте параметризацию!"""

    # TODO: параметризованный тест для SAVE10, SAVE20, HALF
    # TODO: negative тест для неизвестного промокода
    ...


class TestCartTotal:
    """Расчёт стоимости."""

    # TODO: пустая корзина → 0, корзина с товарами → сумма, и т.д.
    ...


class TestCartRemove:
    """Удаление товаров."""

    # TODO: удаление существующего, удаление несуществующего (KeyError)
    ...
