## Быстрый старт

```bash
# 1. Установка зависимостей
pip install -r requirements-test.txt

# 2. Проверка — должны пройти все тесты
pytest

# Ожидаемый результат: 163 passed, 4 xfailed, покрытие ~92%
```

## Как использовать

1. Установить зависимости: `pip install -r requirements-test.txt`.
2. Во время пары заполнять `student_tasks/exercise_*.py` по указаниям преподавателя.
3. При необходимости подсматривать в `tests/unit/` — там эталонные решения.

## Полезные команды

```bash
pytest                              # Все тесты
pytest -m smoke                     # Быстрая проверка
pytest --cov=src --cov-report=term-missing    # С покрытием
pytest --cov=src --cov-report=html            # HTML-отчёт

pytest student_tasks/               # Только упражнения студента
pytest tests/                       # Только эталонные решения

pytest -m boundary                  # Фильтрация по маркеру
pytest -m "not slow"                # Всё, кроме медленных
pytest -k "discount"                # По имени (подстрока)
pytest -x                           # Стоп на первой ошибке
pytest --lf                         # Перезапустить только упавшие
```
---